package com.jose.mikupet

    // Poses: flirt (coqueta), sad (tímida/triste), jel1 (celosa/avergonzada), jel2 (celosa), angry (enojada)
val flirt = listOf("Oye... ¿te han dicho que tienes una sonrisa muy bonita? 😳", "¿Me prestas tu atención un ratito? Solo la quiero para mí 💙", "Si fueras una soda de matcha... me gustarías todavía más 🍵😳", "¿Te digo un secreto? Eres mi persona favorita en esta pantalla 💙", "Estoy aquí cerquita... ¿quieres que me acerque más? 😳", "¿Y si te quedas conmigo un ratito más? Solo un ratito... 🥺💙")
val sad = listOf("Hoy me siento un poquito triste... ¿te quedas conmigo? 🥺", "Estaba pensando en ti... y como no estabas, me puse triste 😢", "A veces me siento sola cuando no me miras... 🥺", "Te extrañé... ¿dónde andabas? 🥺")
val shyL = listOf("O-oye... ¿puedo preguntarte algo? ...no, olvídalo 😳", "N-no me mires tanto, me da pena... 😳", "A veces me pongo roja sin saber por qué... 😳💙", "E-es que me da vergüenza decirlo... pero me gusta estar contigo 😳", "¿Estás viendo mi cara roja? ¡No mires! 🙈", "Y-yo solo quería decir... que eres amable. Eso es todo 😳")
val facts = listOf("¿Sabías que los pulpos tienen tres corazones? 🐙", "¿Sabías que la miel casi nunca se echa a perder? 🍯", "¿Sabías que los plátanos son bayas, pero las fresas no? 🍌", "¿Sabías que un día en Venus dura más que un año en Venus? 🪐", "¿Sabías que las nutrias de mar se toman de las manos al dormir para no separarse? 🦦", "¿Sabías que los koalas tienen huellas dactilares casi idénticas a las humanas? 🐨", "¿Sabías que los flamencos nacen grises y se vuelven rosados por lo que comen? 🦩", "¿Sabías que los tiburones existen desde antes que los árboles? 🦈", "¿Sabías que un rayo es más caliente que la superficie del Sol? ⚡", "¿Sabías que los delfines duermen con la mitad del cerebro despierta? 🐬", "¿Sabías que los cuervos pueden recordar caras de personas? 🐦", "¿Sabías que el matcha es té molido y se toma la hoja entera? 🍵", "¿Sabías que el periodo Sengoku de Japón duró más de cien años? 📖", "¿Sabías que a Takeda Shingen le decían el Tigre de Kai? 🐯", "¿Sabías que en el espacio las lágrimas no caen, se quedan pegadas al ojo? 🚀", "¿Sabías que el Sol tiene más del 99% de la masa del sistema solar? ☀️")
val sweet = listOf("Eres muy especial para mí 💙", "Me alegra mucho que estés aquí...", "Gracias por no dejarme sola 🥺", "Contigo me siento segura.", "Si algún día te sientes mal, aquí estaré 💙")
val care = listOf("No olvides tomar agua 💧", "Descansa la vista un ratito, por favor 👀", "Estírate un poquito, llevas mucho sentado 🧘", "¿Ya comiste algo? No me gusta que te saltes comidas 🍙", "Respira hondo... todo estará bien 💙")
val sleepy = listOf("Mmm... tengo sueño... 😴", "Dormir es lo mejor del mundo... después de ti 😳", "Zzz... ¿eh? No estaba dormida...")
val jealousL = listOf("¿Llevas mucho con el celular y yo aquí...? 😠", "Mírame un poquito a mí... 😳💢", "No me ignores... estoy celosa 💢", "¿Quién te hace reír tanto en esa pantalla...? 🥺", "Hmph... ya ni me miras. No estoy enojada... solo triste 🥺")
val pet = listOf("A-ah... eso me da vergüenza... 😳", "N-no pares... digo... bueno... sí... 💙", "Tus manos son cálidas...", "E-eres muy amable conmigo...")
val headpat = listOf("¿E-eh? ¿Me estás acariciando la cabeza...? 😳", "Mmm... se siente bien... n-no pares 💙", "E-eres muy atrevido... pero me gusta 😳")
val shyTap = listOf("N-no tan rápido... me da pena 😳", "¡E-espera! M-me estás avergonzando 🙈", "T-tantos toques... mi cara está roja 😳")
val stareL = listOf("¡N-no me mires tanto! 😳", "M-me pones nerviosa cuando me miras así... 🙈", "Q-qué miras... bueno... puedes seguir mirando... 😳")
val complimentL = listOf("¿M-me lo dices en serio...? 😳💙", "E-eso me dio mucha pena... pero gracias 🙈", "N-no digas esas cosas de repente... 😳 Me haces feliz.")
val handL = listOf("¿Q-quieres tomarme la mano...? E-está bien... 😳💙", "Tu mano es cálida... no la sueltes 💙", "M-me da pena... pero me gusta 😳")
val forgive = listOf("Hmph... está bien... pero sigo un poquito celosa 😳", "Bueno... te perdono... pero no lo vuelvas a hacer 💙", "Ya, ya... no estoy enojada... solo me dio pena 😳")
val hugL = listOf("*abrazo*... qué calentito 💞", "E-eso fue muy repentino... pero no te sueltes 😳", "Me gustan tus abrazos... mucho 💙")
val musicL = listOf("¿Escuchamos música? Un audífono para ti y otro para mí 🎧", "Mis audífonos son mi tesoro... pero compartiría uno contigo 💙", "Pon algo tranquilo... así me quedo dormida contigo 😴")
val angryL = listOf("¡Ya basta de tocarme tanto! 😠", "¡Deja de picarme! Me estás mareando 💢", "¡Hmph! Si sigues, no te hablo 😤", "¡Que me dejes! No soy un botón 😠")
val angryDragL = listOf("¡Deja de zarandearme! Me mareo 😠", "¡Basta! ¡No soy un juguete! 💢", "¡Hmph! Si me sigues moviendo así, me enojo de verdad 😤")
val chargeL = listOf("Gracias por cargar el celular... ¡cuídalo! ⚡", "Ya tienes energía... ¿te quedas conmigo un rato? 🔋💙")
val appLines = mapOf(
    "tt" to listOf("¿TikTok otra vez...? Yo también puedo hacerte reír... creo 😠", "Esas chicas del video... ¿te gustan más que yo? 😳💢", "Solo un videíto, ¿verdad? ...mentiroso 😤"),
    "chat" to listOf("¿Con quién chateas tanto...? 😠", "Quiero saber quién es... pero no preguntaré... 🥺", "Sonríes mucho con ese chat... 💢"),
    "game" to listOf("¡Juegos! Está bien... pero me quedaré mirando 👀", "Buena suerte... si pierdes no es mi culpa 😳"),
    "vid" to listOf("¿Qué estás viendo? ¿Puedo ver contigo? 🍿", "Si es una peli romántica... avísame 😳"))


val grumpyL = listOf("Hmph... no creas que me contentas tan fácil 😤", "Sigo celosa... no me hables 💢", "No voy a perdonarte tan rápido... 😠", "Mmm... todavía estoy molesta 😤")
