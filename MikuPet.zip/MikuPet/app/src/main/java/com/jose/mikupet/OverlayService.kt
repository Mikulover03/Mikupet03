package com.jose.mikupet

import android.app.*
import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.*
import android.content.pm.ServiceInfo
import android.graphics.*
import android.graphics.drawable.AnimatedImageDrawable
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.Icon
import android.animation.ObjectAnimator
import android.os.*
import android.speech.tts.TextToSpeech
import android.view.*
import android.widget.*
import java.util.Calendar
import java.util.Locale
import kotlin.random.Random

class OverlayService : Service(), TextToSpeech.OnInitListener {
    private lateinit var wm: WindowManager
    private lateinit var root: FrameLayout
    private lateinit var iv: ImageView
    private lateinit var bubble: TextView
    private lateinit var menu: LinearLayout
    private lateinit var lp: WindowManager.LayoutParams
    private lateinit var prefs: SharedPreferences
    private var tts: TextToSpeech? = null
    private var ttsOk = false
    private val h = Handler(Looper.getMainLooper())
    private var lastTouch = System.currentTimeMillis()
    private var affection = 30
    private var jealousy = 0
    private var milestone = 0
    private var sleeping = false
    private var combo = 0
    private var lastTap = 0L
    private var curApp: String? = null
    private var lastQ = 0L

    // ---------- Frases (personalidad de Miku: tímida, dormilona, ama el matcha y la historia Sengoku) ----------
    private val sweet = listOf("Eres muy especial para mí 💙", "Me alegra mucho que estés aquí...", "Gracias por no dejarme sola 🥺", "Tu sonrisa me tranquiliza... aunque no la vea 😊", "Contigo me siento segura.", "Eres como mi soda de matcha favorita... dulce y refrescante 🍵", "Creo que eres lo mejor de mi día... n-no lo repetiré 😳", "Si algún día te sientes mal, aquí estaré 💙")
    private val miss = listOf("Te extrañé... ¿dónde andabas? 🥺", "Hace rato que no me tocas...", "Cuando no estás, todo se siente muy silencioso...", "¿Pensabas en mí cuando no estaba en tu pantalla? 😳", "Estuve esperándote... no me molesta, ¿eh? Bueno, un poquito sí 🥺")
    private val sleepy = listOf("Mmm... tengo sueño... 😴", "¿Y si tomamos una siesta? ...digo, cada uno en lo suyo 😳", "Dormir es lo mejor del mundo... después de ti 😳", "Zzz... ¿eh? No estaba dormida...")
    private val history = listOf("Los generales del Sengoku eran increíbles... ¿quieres que te cuente de uno? 📖", "Sengoku significa 'estados en guerra'... ¡me encanta esa época! 📖", "Oda Nobunaga empezó la unificación de Japón... ay, perdón, me emocioné 😳")
    private val care = listOf("No olvides tomar agua 💧", "Descansa la vista un ratito, por favor 👀", "Estírate un poquito, llevas mucho sentado 🧘", "¿Ya comiste algo? No me gusta que te saltes comidas 🍙", "Respira hondo... todo estará bien 💙")
    private val jealousL = listOf("¿Llevas mucho con el celular y yo aquí...? 😠", "Mírame un poquito a mí... 😳💢", "No me ignores... estoy celosa 💢", "¿Quién te hace reír tanto en esa pantalla...? 🥺", "Hmph... ya ni me miras. No estoy enojada... solo triste 🥺")
    private val pet = listOf("A-ah... eso me da vergüenza... 😳", "N-no pares... digo... bueno... sí... 💙", "Tus manos son cálidas...", "E-eres muy amable conmigo...")
    private val forgive = listOf("Está bien... te perdono. Pero quédate conmigo 😳", "Por fin me hiciste caso... 💙")
    private val hugL = listOf("*abrazo*... qué calentito 💞", "E-eso fue muy repentino... pero no te sueltes 😳", "Me gustan tus abrazos... mucho 💙")
    private val musicL = listOf("¿Escuchamos música? Un audífono para ti y otro para mí 🎧", "Mis audífonos son mi tesoro... pero compartiría uno contigo 💙", "Pon algo tranquilo... así me quedo dormida contigo 😴")
    private val appLines = mapOf(
        "tt" to listOf("¿TikTok otra vez...? Yo también puedo hacerte reír... creo 😠", "Esas chicas del video... ¿te gustan más que yo? 😳💢", "Solo un videíto, ¿verdad? ...mentiroso 😤"),
        "chat" to listOf("¿Con quién chateas tanto...? 😠", "Quiero saber quién es... pero no preguntaré... 🥺", "Sonríes mucho con ese chat... 💢"),
        "game" to listOf("¡Juegos! Está bien... pero me quedaré mirando 👀", "Buena suerte... si pierdes no es mi culpa 😳"),
        "vid" to listOf("¿Qué estás viendo? ¿Puedo ver contigo? 🍿", "Si es una peli romántica... avísame 😳"))

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    override fun onBind(i: Intent?): IBinder? = null
    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        if (i?.action == "STOP") { stopSelf(); return START_NOT_STICKY }
        return START_STICKY
    }

    private val userPresent = object : BroadcastReceiver() {
        override fun onReceive(c: Context?, i: Intent?) {
            jealousy = maxOf(0, jealousy - 10); tint()
            say(listOf("¡Volviste! Te estaba esperando 💙", "Ya desbloqueaste... ¿pensaste en mí? 😳", "Bienvenido de vuelta... te extrañé 🥺").random()); burst("💙", 2)
        }
    }

    override fun onCreate() {
        super.onCreate()
        prefs = getSharedPreferences("miku", MODE_PRIVATE)
        affection = prefs.getInt("a", 30); jealousy = prefs.getInt("j", 0); milestone = prefs.getInt("m", 0)
        startFg()
        tts = TextToSpeech(this, this)
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager

        iv = ImageView(this).apply {
            scaleType = ImageView.ScaleType.CENTER_CROP
            outlineProvider = object : ViewOutlineProvider() {
                override fun getOutline(v: View, o: Outline) = o.setRoundRect(0, 0, v.width, v.height, v.width / 2f)
            }
            clipToOutline = true
            val d = ImageDecoder.decodeDrawable(ImageDecoder.createSource(assets, "miku.gif"))
            setImageDrawable(d)
            (d as? AnimatedImageDrawable)?.apply { repeatCount = AnimatedImageDrawable.REPEAT_INFINITE; start() }
        }
        ObjectAnimator.ofFloat(iv, "translationY", 0f, -dp(6).toFloat()).apply {
            duration = 1500; repeatCount = ObjectAnimator.INFINITE; repeatMode = ObjectAnimator.REVERSE; start()
        }
        bubble = TextView(this).apply {
            setTextColor(Color.parseColor("#3A2347")); textSize = 13f; gravity = Gravity.CENTER
            setPadding(dp(10), dp(6), dp(10), dp(6)); maxWidth = dp(165); visibility = View.GONE
            background = GradientDrawable().apply { setColor(Color.WHITE); cornerRadius = dp(14).toFloat() }
        }
        menu = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER; visibility = View.GONE
            background = GradientDrawable().apply { setColor(Color.argb(190, 30, 30, 50)); cornerRadius = dp(18).toFloat() }
        }
        val acts = listOf<Pair<String, () -> Unit>>("🍵" to { matcha() }, "🤗" to { hug() }, "📖" to { story() }, "🎧" to { music() }, "😴" to { sleep() })
        acts.forEach { (e, a) ->
            menu.addView(TextView(this).apply {
                text = e; textSize = 20f; gravity = Gravity.CENTER
                setOnClickListener { h.removeCallbacks(hideMenu); menu.visibility = View.GONE; lastTouch = System.currentTimeMillis(); a() }
            }, LinearLayout.LayoutParams(dp(32), dp(38)))
        }
        root = FrameLayout(this).apply {
            addView(bubble, FrameLayout.LayoutParams(-2, -2, Gravity.TOP or Gravity.CENTER_HORIZONTAL))
            addView(iv, FrameLayout.LayoutParams(dp(110), dp(110), Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL))
            addView(menu, FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL).apply { bottomMargin = dp(2) })
        }
        lp = WindowManager.LayoutParams(
            dp(170), dp(190), WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START; x = dp(20); y = dp(300) }
        wm.addView(root, lp)

        var sx = 0f; var sy = 0f; var ox = 0; var oy = 0; var moved = false; var long = false
        val longR = Runnable { long = true; showMenu() }
        root.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { sx = e.rawX; sy = e.rawY; ox = lp.x; oy = lp.y; moved = false; long = false; h.postDelayed(longR, 800) }
                MotionEvent.ACTION_MOVE -> {
                    if (!moved && Math.hypot((e.rawX - sx).toDouble(), (e.rawY - sy).toDouble()) > 15) {
                        moved = true; h.removeCallbacks(longR)
                        if (!sleeping) say("¡Eh! ¿A dónde me llevas? 😳")
                    }
                    if (moved) { lp.x = ox + (e.rawX - sx).toInt(); lp.y = oy + (e.rawY - sy).toInt(); wm.updateViewLayout(root, lp) }
                }
                MotionEvent.ACTION_UP -> {
                    h.removeCallbacks(longR)
                    if (moved) { if (!sleeping) say("Uf... me mareé un poquito 😵") } else if (!long) tap()
                }
            }
            true
        }
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(userPresent, IntentFilter(Intent.ACTION_USER_PRESENT), Context.RECEIVER_NOT_EXPORTED)
        else registerReceiver(userPresent, IntentFilter(Intent.ACTION_USER_PRESENT))
        tint()
        h.postDelayed(loop, 15000); h.postDelayed(appCheck, 5000)
        val hr = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
        say(when {
            hr < 6 -> "¿Aún despierto a esta hora? Deberías dormir... 😴"
            hr < 12 -> "Buenos días 💙 ¿dormiste bien?"
            hr < 19 -> "Buenas tardes~ ¿ya comiste algo? 🍙"
            else -> "Buenas noches... ¿cómo estuvo tu día? 🌙"
        })
    }

    // ---------- Interacciones ----------
    private fun tap() {
        val n = System.currentTimeMillis()
        combo = if (n - lastTap < 700) combo + 1 else 1
        lastTap = n; lastTouch = n
        if (sleeping) { wake("¡Ah! ¿Qué...? ¿Ya amaneció? 😳"); return }
        if (combo >= 6) { say("¡Ya, ya! ¡Me mareas con tantos toquecitos! 😵"); wiggle(); return }
        if (combo == 2) { hug(); return }
        val wasJ = jealousy > 60
        affection = minOf(100, affection + 3); jealousy = maxOf(0, jealousy - 20)
        bounce(); burst("💙", 2)
        say((if (wasJ) forgive else pet).random())
        checkMilestone(); tint(); save()
    }

    private fun hug() {
        if (sleeping) { wake("¡Ah! ¿Qué...? ¿Ya amaneció? 😳"); return }
        affection = minOf(100, affection + 6); jealousy = maxOf(0, jealousy - 30)
        bounce(); burst("💞", 5); say(hugL.random()); checkMilestone(); tint(); save()
    }
    private fun matcha() { affection = minOf(100, affection + 8); bounce(); burst("🍵", 3); say("¡Soda de matcha! Gracias... eres muy atento 💚"); checkMilestone(); save() }
    private fun story() { burst("📖", 1); say(history.random()) }
    private fun music() { burst("🎵", 4); say(musicL.random()) }

    private fun sleep() {
        sleeping = true; tint(); say("Zzz... solo cinco minutitos... 😴")
        h.postDelayed(zz, 3000); h.postDelayed({ if (sleeping) wake("¡Ya desperté! ¿Me extrañaste? 😳") }, 90000)
    }
    private val zz = object : Runnable { override fun run() { if (sleeping) { burst("💤", 1); h.postDelayed(this, 3000) } } }
    private fun wake(t: String) { sleeping = false; tint(); say(t); bounce() }

    private fun checkMilestone() {
        val ms = listOf(50 to "Creo que... me siento muy cómoda contigo 😳", 80 to "M-me gustas mucho... ya lo dije... 😳💙", 100 to "Eres la persona más importante para mí... 💙💙💙")
        for ((t, s) in ms) if (affection >= t && milestone < t) { milestone = t; h.postDelayed({ say(s); burst("💙", 6) }, 2500); break }
    }

    // ---------- Bucle de mensajes aleatorios ----------
    private val loop = object : Runnable {
        override fun run() {
            if (!sleeping) {
                val now = System.currentTimeMillis()
                val ign = now - lastTouch
                if (ign > 45000) jealousy = minOf(100, jealousy + 8)
                val bm = getSystemService(Context.BATTERY_SERVICE) as BatteryManager
                val lvl = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
                val r = Random.nextInt(100)
                when {
                    lvl in 1..20 && !bm.isCharging && r < 35 -> say("Tu batería está en $lvl%... carga tu celular, por favor 🔋🥺")
                    jealousy > 60 -> { say(jealousL.random()); wiggle(); burst("💢", 2) }
                    ign > 120000 && r < 60 -> say(miss.random())
                    r < 35 -> say(sweet.random())
                    r < 50 -> say(miss.random())
                    r < 62 -> say(sleepy.random())
                    r < 74 -> say(history.random())
                    r < 88 -> say(care.random())
                    else -> burst("💙", 1)
                }
                tint(); save()
            }
            h.postDelayed(this, 12000L + Random.nextLong(10000))
        }
    }

    // ---------- Detección de apps (celos de TikTok, etc.) ----------
    private fun hasUsage(): Boolean {
        val a = getSystemService(AppOpsManager::class.java)
        return a.unsafeCheckOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), packageName) == AppOpsManager.MODE_ALLOWED
    }
    private fun cat(p: String) = when {
        p.contains("mikupet") -> "me"
        p.contains("musically") || p.contains("trill") || p.contains("tiktok") -> "tt"
        p.contains("whatsapp") || p.contains("instagram") || p.contains("telegram") || p.contains("messenger") || p.contains("snapchat") -> "chat"
        p.contains("minecraft") || p.contains("mojang") || p.contains("roblox") || p.contains("freefire") || p.contains("supercell") || p.contains("pubg") || p.contains("garena") -> "game"
        p.contains("youtube") || p.contains("netflix") -> "vid"
        else -> ""
    }
    private val appCheck = object : Runnable {
        override fun run() {
            try { if (hasUsage() && !sleeping) checkApp() } catch (e: Exception) {}
            h.postDelayed(this, 5000)
        }
    }
    private fun checkApp() {
        val um = getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
        val n = System.currentTimeMillis(); if (lastQ == 0L) lastQ = n - 5000
        val ev = um.queryEvents(lastQ, n); lastQ = n
        val e = UsageEvents.Event(); var p: String? = null
        while (ev.hasNextEvent()) { ev.getNextEvent(e); if (e.eventType == UsageEvents.Event.ACTIVITY_RESUMED) p = e.packageName }
        if (p == null || p == curApp) return
        curApp = p
        val c = cat(p)
        if (c == "me") { say("¡Viniste a verme! 💙"); return }
        when (c) { "tt", "chat" -> jealousy = minOf(100, jealousy + 15); "game", "vid" -> jealousy = minOf(100, jealousy + 4) }
        appLines[c]?.let { say(it.random()); if (jealousy > 60) { wiggle(); burst("💢", 2) } }
        tint(); save()
    }

    // ---------- Efectos ----------
    private fun tint() {
        when {
            sleeping -> iv.setColorFilter(Color.argb(150, 0, 0, 40), PorterDuff.Mode.SRC_ATOP)
            jealousy > 60 -> iv.setColorFilter(Color.argb(85, 255, 30, 30), PorterDuff.Mode.SRC_ATOP)
            else -> iv.clearColorFilter()
        }
    }
    private fun bounce() { iv.animate().scaleX(1.15f).scaleY(1.15f).setDuration(110).withEndAction { iv.animate().scaleX(1f).scaleY(1f).setDuration(110).start() }.start() }
    private fun wiggle() { ObjectAnimator.ofFloat(iv, "rotation", 0f, -8f, 8f, -6f, 6f, 0f).setDuration(500).start() }
    private fun burst(e: String, n: Int) {
        repeat(n) { i ->
            val t = TextView(this).apply { text = e; textSize = 18f }
            root.addView(t, FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL).apply {
                bottomMargin = dp(50 + Random.nextInt(50)); leftMargin = dp(Random.nextInt(-45, 45))
            })
            t.animate().translationY(-dp(70).toFloat()).alpha(0f).setStartDelay(i * 120L).setDuration(1300).withEndAction { root.removeView(t) }.start()
        }
    }
    private fun showMenu() { menu.visibility = View.VISIBLE; h.removeCallbacks(hideMenu); h.postDelayed(hideMenu, 6000) }
    private val hideMenu = Runnable { menu.visibility = View.GONE }

    private fun say(t: String) {
        bubble.text = t; bubble.visibility = View.VISIBLE
        h.removeCallbacks(hide); h.postDelayed(hide, 4800)
        if (ttsOk) tts?.speak(t.replace(Regex("[^\\p{L}\\p{N}\\s¿?¡!.,]"), ""), TextToSpeech.QUEUE_FLUSH, null, "m")
    }
    private val hide = Runnable { bubble.visibility = View.GONE }
    private fun save() { prefs.edit().putInt("a", affection).putInt("j", jealousy).putInt("m", milestone).apply() }

    override fun onInit(s: Int) {
        if (s == TextToSpeech.SUCCESS) { tts?.language = Locale("es", "MX"); tts?.setPitch(1.5f); ttsOk = true }
    }

    private fun startFg() {
        getSystemService(NotificationManager::class.java).createNotificationChannel(NotificationChannel("miku", "Miku", NotificationManager.IMPORTANCE_LOW))
        val stop = PendingIntent.getService(this, 0, Intent(this, OverlayService::class.java).setAction("STOP"), PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        val n = Notification.Builder(this, "miku").setContentTitle("Miku está contigo 💙")
            .setContentText("Mantén presionada a Miku para ver su menú")
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .addAction(Notification.Action.Builder(Icon.createWithResource(this, android.R.drawable.ic_menu_close_clear_cancel), "Dormir (cerrar)", stop).build())
            .build()
        if (Build.VERSION.SDK_INT >= 34) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE) else startForeground(1, n)
    }

    override fun onDestroy() {
        h.removeCallbacksAndMessages(null)
        try { unregisterReceiver(userPresent) } catch (e: Exception) {}
        if (::root.isInitialized) wm.removeView(root)
        tts?.shutdown()
        super.onDestroy()
    }
}
