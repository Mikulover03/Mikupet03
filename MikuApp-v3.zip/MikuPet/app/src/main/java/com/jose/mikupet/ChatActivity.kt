package com.jose.mikupet

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.text.InputType
import android.view.WindowManager
import android.view.inputmethod.EditorInfo
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView

class ChatActivity : Activity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_VISIBLE or WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE)
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(40, 30, 40, 30) }
        col.addView(TextView(this).apply { text = "Habla con Miku 💙"; textSize = 16f })
        val et = EditText(this).apply {
            hint = "Escríbele a Miku..."
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
            imeOptions = EditorInfo.IME_ACTION_SEND
            setOnEditorActionListener { _, _, _ -> send(text.toString()); true }
        }
        col.addView(et)
        col.addView(Button(this).apply { text = "Enviar"; setOnClickListener { send(et.text.toString()) } })
        setContentView(col)
        et.requestFocus()
    }

    private fun send(t: String) {
        if (t.isNotBlank()) startService(Intent(this, OverlayService::class.java).setAction("CHAT").putExtra("t", t.trim()))
        finish()
    }
}
