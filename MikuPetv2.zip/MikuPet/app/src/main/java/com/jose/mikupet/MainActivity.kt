package com.jose.mikupet

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER; setPadding(60, 60, 60, 60) }
        col.addView(TextView(this).apply { text = "Miku Nakano 💙\nMascota en pantalla"; textSize = 22f; gravity = Gravity.CENTER })
        col.addView(Button(this).apply { text = "1. Activar a Miku"; setOnClickListener { start() } })
        col.addView(Button(this).apply {
            text = "2. (Opcional) Que vea qué app uso → celos de TikTok"
            setOnClickListener { startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)) }
        })
        col.addView(Button(this).apply { text = "Desactivar"; setOnClickListener { stopService(Intent(this@MainActivity, OverlayService::class.java)) } })
        col.addView(TextView(this).apply {
            text = "\nToca: mimar · Doble toque: abrazo · Mantén: menú (🍵🤗📖🎧😴) · Arrastra: moverla"
            gravity = Gravity.CENTER
        })
        setContentView(col)
    }

    private fun start() {
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Activa \"Mostrar sobre otras apps\" y vuelve", Toast.LENGTH_LONG).show()
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            return
        }
        if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf("android.permission.POST_NOTIFICATIONS"), 1)
        startForegroundService(Intent(this, OverlayService::class.java))
    }
}
