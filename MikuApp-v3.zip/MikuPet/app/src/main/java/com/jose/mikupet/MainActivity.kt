package com.jose.mikupet

import android.app.Activity
import android.content.Intent
import android.content.SharedPreferences
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.view.Gravity
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {
    private lateinit var prefs: SharedPreferences

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        prefs = getSharedPreferences("miku", MODE_PRIVATE)
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(50, 50, 50, 50) }
        fun label(s: String) = TextView(this).apply { text = s; setPadding(0, 28, 0, 6) }
        fun field(hint: String, key: String, secret: Boolean, def: String = "") = EditText(this).apply {
            this.hint = hint; setText(prefs.getString(key, def)); isSingleLine = true
            inputType = InputType.TYPE_CLASS_TEXT or (if (secret) InputType.TYPE_TEXT_VARIATION_PASSWORD else 0)
        }

        col.addView(TextView(this).apply { text = "Miku Nakano 💙\nMiku App"; textSize = 22f; gravity = Gravity.CENTER })
        col.addView(Button(this).apply { text = "1. Activar a Miku"; setOnClickListener { start() } })
        col.addView(Button(this).apply {
            text = "2. (Opcional) Que vea qué app uso → celos de TikTok"
            setOnClickListener { startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)) }
        })
        col.addView(Button(this).apply { text = "Desactivar"; setOnClickListener { stopService(Intent(this@MainActivity, OverlayService::class.java)) } })
        col.addView(Switch(this).apply {
            text = "Modo ahorro de batería"; isChecked = prefs.getBoolean("saver", false)
            setOnCheckedChangeListener { _, on -> prefs.edit().putBoolean("saver", on).apply() }
            setPadding(0, 30, 0, 0)
        })

        col.addView(label("IA de Miku (para conversar). Usa solo una:"))
        val g = field("Llave de Gemini (gratis)", "gkey", true)
        val c = field("Llave de Claude (opcional)", "ckey", true)
        val m = field("Modelo de Gemini", "gmodel", false, "gemini-2.5-flash")
        col.addView(g); col.addView(c); col.addView(m)
        col.addView(Button(this).apply {
            text = "Guardar"
            setOnClickListener {
                prefs.edit().putString("gkey", g.text.toString().trim()).putString("ckey", c.text.toString().trim())
                    .putString("gmodel", m.text.toString().trim()).apply()
                Toast.makeText(this@MainActivity, "Guardado 💙", Toast.LENGTH_SHORT).show()
            }
        })
        col.addView(TextView(this).apply {
            text = "\nLlave gratis: aistudio.google.com/apikey. Se guarda solo en tu celular.\n\nToca: mimar · Doble toque: abrazo · Toca la cabeza: caricia · Mantén presionada: menú · Arrastra: moverla (si la mueves mucho se enoja)"
        })
        setContentView(ScrollView(this).apply { addView(col) })
    }

    private fun start() {
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Activa \"Mostrar sobre otras apps\" y vuelve", Toast.LENGTH_LONG).show()
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            return
        }
        if (Build.VERSION.SDK_INT >= 33) requestPermissions(arrayOf("android.permission.POST_NOTIFICATIONS"), 1)
        startForegroundService(Intent(this, OverlayService::class.java))
    }
}
