package com.jose.mikupet

import android.animation.ObjectAnimator
import android.animation.ValueAnimator
import android.app.*
import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.*
import android.content.pm.ServiceInfo
import android.graphics.*
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.Icon
import android.os.*
import android.speech.tts.TextToSpeech
import android.view.*
import android.view.animation.AccelerateDecelerateInterpolator
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.*
import java.text.Normalizer
import java.util.Calendar
import java.util.Locale
import kotlin.random.Random

class OverlayService : Service(), TextToSpeech.OnInitListener, SharedPreferences.OnSharedPreferenceChangeListener {
    private lateinit var wm: WindowManager
    private lateinit var root: LinearLayout
    private lateinit var stage: FrameLayout
    private lateinit var iv: ImageView
    private lateinit var bubble: TextView
    private lateinit var menu: LinearLayout
    private lateinit var chatRow: LinearLayout
    private lateinit var et: EditText
    private lateinit var lp: WindowManager.LayoutParams
    private lateinit var prefs: SharedPreferences
    private lateinit var bob: ObjectAnimator
    private var roamAnim: ValueAnimator? = null
    private var tts: TextToSpeech? = null
    private var ttsOk = false
    private val h = Handler(Looper.getMainLooper())
    private val bmp = HashMap<String, Bitmap>()
    private val history = ArrayList<Pair<String, String>>()
    private var base = "flirt"
    private var cur = ""
    private var baseUntil = 0L
    private var lastBubble = 0L
    private var lastTouch = System.currentTimeMillis()
    private var affection = 30
    private var jealousy = 0
    private var milestone = 0
    private var sleeping = false
    private var saver = false
    private var chatOpen = false
    private var dragging = false
    private var chatPrevY = 0
    private var combo = 0
    private var comfort = 0
    private var lastTap = 0L
    private var dragPath = 0f
    private var dragWin = 0L
    private var angryUntil = 0L
    private var curApp: String? = null
    private var lastQ = 0L

    private fun nowMs() = System.currentTimeMillis()
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun jel() = listOf("jel1", "jel2").random()
    private fun shyPose() = listOf("sad", "jel1").random()
    private fun norm(s: String) = Normalizer.normalize(s.lowercase(), Normalizer.Form.NFD).replace(Regex("\\p{M}+"), "")
    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        if (i?.action == "STOP") { stopSelf(); return START_NOT_STICKY }
        return START_STICKY
    }

    private val rec = object : BroadcastReceiver() {
        override fun onReceive(c: Context?, i: Intent?) {
            if (chatOpen) return
            if (i?.action == Intent.ACTION_POWER_CONNECTED) { if (jealousy <= 60) setBase("flirt", 30000); say(chargeL.random()); burst("⚡", 2); return }
            if (jealousy > 60) { say(jealousL.random()); return }
            setBase("flirt", 30000); burst("💙", 2)
            say(listOf("¡Volviste! Te estaba esperando 💙", "Ya desbloqueaste... ¿pensaste en mí? 😳", "Bienvenido de vuelta... te extrañé 🥺").random())
        }
    }

    override fun onCreate() {
        super.onCreate()
        prefs = getSharedPreferences("miku", MODE_PRIVATE)
        affection = prefs.getInt("a", 30); jealousy = prefs.getInt("j", 0); milestone = prefs.getInt("m", 0)
        startFg()
        tts = TextToSpeech(this, this)
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        listOf("flirt", "sad", "jel1", "jel2", "angry").forEach { n ->
            assets.open("$n.png").use {
                val b = BitmapFactory.decodeStream(it)
                val s = minOf(1f, dp(125).toFloat() / b.width, dp(170).toFloat() / b.height)
                bmp[n] = Bitmap.createScaledBitmap(b, (b.width * s).toInt(), (b.height * s).toInt(), true)
            }
        }

        iv = ImageView(this).apply { scaleType = ImageView.ScaleType.FIT_CENTER; setLayerType(View.LAYER_TYPE_HARDWARE, null) }
        bob = ObjectAnimator.ofFloat(iv, "translationY", 0f, -dp(5).toFloat()).apply {
            duration = 1600; repeatCount = ObjectAnimator.INFINITE; repeatMode = ObjectAnimator.REVERSE; start()
        }
        bubble = TextView(this).apply {
            setTextColor(Color.parseColor("#3A2347")); textSize = 13f; gravity = Gravity.CENTER
            setPadding(dp(10), dp(6), dp(10), dp(6)); maxWidth = dp(165); visibility = View.GONE
            background = GradientDrawable().apply { setColor(Color.WHITE); cornerRadius = dp(14).toFloat() }
        }
        et = EditText(this).apply {
            hint = "Escríbele a Miku..."; isSingleLine = true; textSize = 13f
            setTextColor(Color.BLACK); setHintTextColor(Color.GRAY)
            imeOptions = EditorInfo.IME_ACTION_SEND
            setPadding(dp(10), dp(6), dp(10), dp(6))
            background = GradientDrawable().apply { setColor(Color.WHITE); cornerRadius = dp(14).toFloat() }
            setOnEditorActionListener { _, _, _ -> sendChat(); true }
        }
        chatRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; visibility = View.GONE
            setPadding(dp(6), dp(4), dp(6), dp(4))
            background = GradientDrawable().apply { setColor(Color.argb(200, 30, 30, 50)); cornerRadius = dp(18).toFloat() }
            addView(et, LinearLayout.LayoutParams(dp(170), -2))
            addView(TextView(context).apply { text = "➤"; textSize = 20f; setTextColor(Color.WHITE); setPadding(dp(10), 0, dp(6), 0); setOnClickListener { sendChat() } })
            addView(TextView(context).apply { text = "✕"; textSize = 18f; setTextColor(Color.WHITE); setPadding(dp(6), 0, dp(6), 0); setOnClickListener { closeChat() } })
        }
        menu = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; visibility = View.GONE; setPadding(dp(4), dp(2), dp(4), dp(2))
            background = GradientDrawable().apply { setColor(Color.argb(200, 30, 30, 50)); cornerRadius = dp(18).toFloat() }
        }
        val rows = listOf(
            listOf<Pair<String, () -> Unit>>("🍵" to { matcha() }, "🤗" to { hug() }, "📖" to { fact() }, "🎧" to { music() }, "😴" to { sleep() }),
            listOf<Pair<String, () -> Unit>>("💬" to { openChat() }, "🙈" to { stare() }, "💌" to { compliment() }, "🫶" to { hand() }, "🔋" to { toggleSaver() }))
        rows.forEach { r ->
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            r.forEach { (e, a) ->
                row.addView(TextView(this).apply {
                    text = e; textSize = 19f; gravity = Gravity.CENTER
                    setOnClickListener { h.removeCallbacks(hideMenu); menu.visibility = View.GONE; lastTouch = nowMs(); a() }
                }, LinearLayout.LayoutParams(dp(30), dp(36)))
            }
            menu.addView(row)
        }
        stage = FrameLayout(this).apply {
            addView(iv, FrameLayout.LayoutParams(dp(125), dp(170), Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL))
            addView(menu, FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL).apply { bottomMargin = dp(2) })
        }
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL
            addView(bubble, LinearLayout.LayoutParams(-2, -2))
            addView(chatRow, LinearLayout.LayoutParams(-2, -2))
            addView(stage, LinearLayout.LayoutParams(dp(165), dp(170)))
        }
        lp = WindowManager.LayoutParams(
            -2, -2, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS or WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.BOTTOM or Gravity.START; x = dp(10); y = dp(120); softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_NOTHING }
        wm.addView(root, lp)
        setBase("flirt")
        prefs.registerOnSharedPreferenceChangeListener(this)
        applySaver()

        var sx = 0f; var sy = 0f; var lx = 0f; var ly = 0f; var ox = 0; var oy = 0; var moved = false; var long = false
        val longR = Runnable { long = true; showMenu() }
        root.setOnTouchListener { _, e ->
            if (chatOpen) return@setOnTouchListener true
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    dragging = true; roamAnim?.cancel()
                    sx = e.rawX; sy = e.rawY; ox = lp.x; oy = lp.y; moved = false; long = false; h.postDelayed(longR, 800)
                }
                MotionEvent.ACTION_MOVE -> {
                    if (!moved && Math.hypot((e.rawX - sx).toDouble(), (e.rawY - sy).toDouble()) > 15) {
                        moved = true; h.removeCallbacks(longR); lx = e.rawX; ly = e.rawY
                        bob.cancel(); iv.translationY = 0f
                        if (!sleeping && jealousy <= 60) say("¡Eh! ¿A dónde me llevas? 😳")
                    }
                    if (moved) {
                        val t = nowMs()
                        if (t - dragWin > 8000) { dragWin = t; dragPath = 0f }
                        dragPath += Math.hypot((e.rawX - lx).toDouble(), (e.rawY - ly).toDouble()).toFloat(); lx = e.rawX; ly = e.rawY
                        lp.x = ox + (e.rawX - sx).toInt(); lp.y = oy - (e.rawY - sy).toInt(); wm.updateViewLayout(root, lp)
                        if (dragPath > dp(1400) && t > angryUntil && !sleeping) { dragPath = 0f; angryUntil = t + 12000; angry(angryDragL) }
                    }
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    dragging = false; h.removeCallbacks(longR)
                    if (!saver && !bob.isRunning) bob.start()
                    if (moved) { if (!sleeping && jealousy <= 60 && nowMs() > angryUntil) say("Uf... me mareé un poquito 😵") }
                    else if (!long && e.action == MotionEvent.ACTION_UP) tap(e.y - stage.top)
                }
            }
            true
        }
        val f = IntentFilter().apply { addAction(Intent.ACTION_USER_PRESENT); addAction(Intent.ACTION_POWER_CONNECTED) }
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(rec, f, Context.RECEIVER_NOT_EXPORTED) else registerReceiver(rec, f)
        h.postDelayed(loop, 45000); h.postDelayed(appCheck, 5000); h.postDelayed(roamR, 20000)
        val hr = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
        say(when {
            hr < 6 -> "¿Aún despierto a esta hora? Deberías dormir... 😴"
            hr < 12 -> "Buenos días 💙 ¿dormiste bien?"
            hr < 19 -> "Buenas tardes~ ¿ya comiste algo? 🍙"
            else -> "Buenas noches... ¿cómo estuvo tu día? 🌙"
        })
    }

    // ---------- Poses (con inercia: no cambia de emoción tan rápido) ----------
    private fun show(p: String) {
        if (p == cur) return
        val b = bmp[p] ?: return
        cur = p
        iv.animate().alpha(0.2f).setDuration(110).withEndAction { iv.setImageBitmap(b); iv.animate().alpha(1f).setDuration(110).start() }.start()
    }
    private fun setBase(p: String, hold: Long = 0) { comfort = 0; base = p; baseUntil = nowMs() + hold; h.removeCallbacks(revert); show(p) }
    private fun tmp(p: String, ms: Long) { show(p); h.removeCallbacks(revert); h.postDelayed(revert, ms) }
    private val revert = Runnable { show(base) }

    // ---------- Interacciones ----------
    private fun bubbleFree() = nowMs() - lastBubble > 5000

    // Tocarla NO cambia su pose ni su emoción: solo rebota, suelta corazones y, a veces, una burbuja acorde a su ánimo
    private fun tap(y: Float) {
        val n = nowMs()
        combo = if (n - lastTap < 700) combo + 1 else 1
        lastTap = n; lastTouch = n
        if (sleeping) { wake("¡Ah! ¿Qué...? ¿Ya amaneció? 😳"); return }
        when {
            combo >= 5 -> angry(angryL)
            jealousy > 60 -> soothe(4)
            else -> {
                affection = minOf(100, affection + 2); jealousy = maxOf(0, jealousy - 5)
                bounce()
                if (base == "sad") { burst("💙", 1); comfortStep(if (combo == 2) 2 else 1) }
                else {
                    burst("💗", if (combo == 2) 4 else 1)
                    if (bubbleFree()) say((if (combo >= 3) shyTap else if (combo == 2) hugL else if (y < stage.height * 0.3f) headpat else pet).random())
                }
                checkMilestone(); save()
            }
        }
    }

    // Triste: hay que consolarla varias veces antes de que se anime
    private fun comfortStep(k: Int) {
        comfort += k
        if (comfort >= 5) { setBase("flirt", 60000); say(cheerL.random()); burst("💙", 3) }
        else if (bubbleFree()) say(sadTap.random())
    }

    // Celosa: tocarla casi no la contenta; no cambia de pose ni sale burbuja hasta que se le pase poco a poco
    private fun soothe(a: Int) {
        val before = jealousy
        jealousy = maxOf(0, jealousy - a)
        burst("💢", 1); wiggle()
        if (before > 60 && jealousy <= 60) { setBase("jel1", 60000); say(forgive.random()); burst("💙", 2) }
        save()
    }
    private fun jealousGate(a: Int): Boolean {
        if (jealousy <= 60) return false
        soothe(a)
        if (jealousy > 60) say(grumpyL.random())
        return true
    }

    private fun angry(lines: List<String>) {
        affection = maxOf(0, affection - 2)
        tmp("angry", 9000); say(lines.random()); wiggle(); burst("💢", 3); save()
    }
    private fun hug() {
        if (sleeping) { wake("¡Ah! ¿Qué...? ¿Ya amaneció? 😳"); return }
        affection = minOf(100, affection + 6)
        if (jealousGate(10)) { save(); return }
        jealousy = maxOf(0, jealousy - 30)
        setBase("flirt", 30000); bounce(); burst("💞", 5); say(hugL.random()); checkMilestone(); save()
    }
    private fun matcha() {
        affection = minOf(100, affection + 8)
        if (jealousGate(8)) { save(); return }
        setBase("flirt", 30000); bounce(); burst("🍵", 3); say("¡Soda de matcha! Gracias... eres muy atento 💚"); checkMilestone(); save()
    }
    private fun compliment() {
        affection = minOf(100, affection + 4)
        if (jealousGate(8)) { save(); return }
        setBase(shyPose(), 40000); burst("💗", 4); say(complimentL.random()); checkMilestone(); save()
    }
    private fun hand() {
        affection = minOf(100, affection + 5)
        if (jealousGate(8)) { save(); return }
        tmp("flirt", 7000); burst("💙", 4); say(handL.random()); checkMilestone(); save()
    }
    private fun stare() {
        affection = minOf(100, affection + 2)
        if (jealous()) { say(grumpyL.random()); return }
        setBase(shyPose(), 40000); burst("😳", 3); say(stareL.random()); checkMilestone(); save()
    }
    private fun jealous() = jealousy > 60
    private fun fact() { if (!jealous()) setBase("flirt", 30000); burst("📖", 1); say(facts.random(), 7000) }
    private fun music() { if (!jealous()) setBase("flirt", 30000); burst("🎵", 4); say(musicL.random()) }
    private fun toggleSaver() {
        saver = !saver; prefs.edit().putBoolean("saver", saver).apply(); applySaver()
        say(if (saver) "Modo ahorro activado 🔋 Me muevo menos para gastar menos." else "Modo ahorro desactivado ✨ ¡Ya puedo flotar otra vez!")
    }
    private fun applySaver() {
        saver = prefs.getBoolean("saver", false)
        if (saver) { bob.cancel(); iv.translationY = 0f; roamAnim?.cancel() } else if (!bob.isRunning && !dragging) bob.start()
    }
    override fun onSharedPreferenceChanged(sp: SharedPreferences?, key: String?) { if (key == "saver") applySaver() }

    private fun sleep() {
        sleeping = true; roamAnim?.cancel(); tint(); say("Zzz... solo cinco minutitos... 😴")
        h.postDelayed(zz, 3000); h.postDelayed({ if (sleeping) wake("¡Ya desperté! ¿Me extrañaste? 😳") }, 90000)
    }
    private val zz = object : Runnable { override fun run() { if (sleeping) { burst("💤", 1); h.postDelayed(this, 3000) } } }
    private fun wake(t: String) { sleeping = false; tint(); if (!jealous()) setBase("flirt", 30000); say(t); bounce() }

    private fun checkMilestone() {
        val ms = listOf(50 to "Creo que... me siento muy cómoda contigo 😳", 80 to "M-me gustas mucho... ya lo dije... 😳💙", 100 to "Eres la persona más importante para mí... 💙💙💙")
        for ((t, s) in ms) if (affection >= t && milestone < t) { milestone = t; h.postDelayed({ say(s); burst("💙", 6) }, 2500); break }
    }

    // ---------- Chat dentro de la burbuja flotante ----------
    private fun openChat() {
        if (chatOpen) return
        chatOpen = true; roamAnim?.cancel(); chatPrevY = lp.y
        chatRow.visibility = View.VISIBLE
        lp.flags = lp.flags and WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE.inv()
        lp.y = maxOf(lp.y, (resources.displayMetrics.heightPixels * 0.45f).toInt())
        wm.updateViewLayout(root, lp)
        et.requestFocus()
        h.postDelayed({ (getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager).showSoftInput(et, InputMethodManager.SHOW_IMPLICIT) }, 250)
    }
    private fun closeChat() {
        if (!chatOpen) return
        chatOpen = false
        (getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager).hideSoftInputFromWindow(et.windowToken, 0)
        et.clearFocus(); chatRow.visibility = View.GONE
        lp.flags = lp.flags or WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
        lp.y = chatPrevY
        wm.updateViewLayout(root, lp)
    }
    private fun sendChat() {
        val t = et.text.toString().trim()
        et.setText("")
        closeChat()
        if (t.isNotEmpty()) chat(t)
    }

    private fun persona() = "Eres Miku Nakano (de Las quintillizas) como mascota virtual en la pantalla del celular del usuario. " +
        "Eres muy tímida y vergonzosa, tranquila, dormilona, amas el refresco de matcha, tus audífonos y la historia del periodo Sengoku; a veces te pones celosa. " +
        "Hablas en español, con ternura, con tartamudeos leves (\"e-eh\", \"n-no\", \"...\") y emojis. Responde SIEMPRE en 1 o 2 frases cortas (máximo 30 palabras). " +
        "Tu estado: cariño ${affection}/100, celos ${jealousy}/100. Si tus celos son mayores a 60, sigues molesta y no te contentas rápido: respondes seca y celosa. " +
        "Empieza tu respuesta con UNA etiqueta de pose entre corchetes según cómo te sientas: [flirt] [sad] [shy] [jealous] [angry]. " +
        "Mantén todo tierno y apto para todo público. Si el usuario dice que se siente muy mal, responde con cariño y sugiérele hablar con alguien de confianza. " +
        "Si te preguntan en serio si eres una IA, di con sinceridad que eres una mascota virtual con inteligencia artificial."

    private fun trimHistory() {
        while (history.size > 12) history.removeAt(0)
        while (history.isNotEmpty() && history[0].first != "user") history.removeAt(0)
    }

    private fun chat(text: String) {
        lastTouch = nowMs(); jealousy = maxOf(0, jealousy - 3)
        if (sleeping) { sleeping = false; tint() }
        val ok = prefs.getString("gkey", "").orEmpty().isNotBlank() || prefs.getString("ckey", "").orEmpty().isNotBlank()
        if (!ok) { local(text); return }
        say("Mmm... 💭", 40000)
        history.add("user" to text); trimHistory()
        val snap = ArrayList(history)
        val sys = persona()
        Thread {
            try {
                val out = Ai.ask(prefs, snap, sys)
                h.post { history.add("assistant" to out); onReply(out) }
            } catch (e: Exception) {
                h.post {
                    if (history.isNotEmpty() && history.last().first == "user") history.removeAt(history.size - 1)
                    tmp("sad", 6000); say("No pude pensar bien... (${e.message}) 🥺", 12000)
                }
            }
        }.start()
    }

    private fun onReply(raw: String) {
        val tag = Regex("\\[(flirt|sad|shy|jealous|angry)]").find(raw)?.groupValues?.get(1)
        val txt = raw.replace(Regex("\\[(flirt|sad|shy|jealous|angry)]"), "").trim()
        when {
            tag == "angry" -> tmp("angry", 8000)
            jealousy > 60 -> setBase(jel(), 45000)
            tag == "sad" -> setBase("sad", 45000)
            tag == "shy" -> setBase(shyPose(), 45000)
            tag == "jealous" -> setBase(jel(), 45000)
            else -> setBase("flirt", 45000)
        }
        affection = minOf(100, affection + 1)
        say(txt, 10000); save()
    }

    private fun local(text: String) {
        val t = norm(text)
        when {
            Regex("bonit|lind|hermos|guap|precios|kawaii").containsMatchIn(t) -> { if (!jealous()) setBase(shyPose(), 40000); say(if (jealous()) grumpyL.random() else complimentL.random()) }
            Regex("te quiero|te amo|amor").containsMatchIn(t) -> { affection = minOf(100, affection + 5); if (!jealous()) setBase("flirt", 40000); say(if (jealous()) grumpyL.random() else flirt.random()) }
            Regex("hola|buenas|hey").containsMatchIn(t) -> { if (!jealous()) setBase("flirt", 40000); say("¡H-hola! 😳💙") }
            else -> { say(listOf("Hmm... cuéntame más 💭", "Te escucho... 💙", "Todavía no tengo cerebro de IA... pon tu llave en la app 😳").random()) }
        }
        save()
    }

    // ---------- Eventos aleatorios cada pocos minutos ----------
    private val loop = object : Runnable {
        override fun run() {
            if (!sleeping && !chatOpen) {
                val t = nowMs(); val ign = t - lastTouch
                jealousy = if (ign > 120000) minOf(100, jealousy + 15) else maxOf(0, jealousy - 5)
                val bm = getSystemService(Context.BATTERY_SERVICE) as BatteryManager
                val lvl = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
                val r = Random.nextInt(100)
                val holding = t < baseUntil || t - lastBubble < 40000
                when {
                    lvl in 1..15 && !bm.isCharging && !saver -> { prefs.edit().putBoolean("saver", true).apply(); applySaver(); say("Tu batería está en $lvl%... activé el modo ahorro 🔋🥺") }
                    holding -> {}
                    lvl in 1..20 && !bm.isCharging && r < 30 -> { setBase("sad", 60000); say("Tu batería está en $lvl%... carga tu celular, por favor 🔋🥺") }
                    jealousy > 60 -> { setBase(jel(), 120000); say(jealousL.random()); wiggle(); burst("💢", 2) }
                    r < 20 -> { setBase("flirt", 90000); say(flirt.random()); burst("💙", 2) }
                    r < 40 -> { setBase("flirt", 90000); say(facts.random(), 7000) }
                    r < 52 -> { setBase("sad", 90000); say(sad.random()) }
                    r < 68 -> { setBase(shyPose(), 90000); say(shyL.random()); burst("😳", 2) }
                    r < 78 -> { setBase("flirt", 90000); say(sweet.random()) }
                    r < 88 -> { setBase("flirt", 90000); say(care.random()) }
                    else -> { setBase("sad", 90000); say(sleepy.random()) }
                }
                save()
            }
            h.postDelayed(this, (70000L + Random.nextLong(100000)) * (if (saver) 2 else 1))
        }
    }

    // ---------- Anda libre por la pantalla (sin IA, solo código) ----------
    private val roamR = object : Runnable {
        override fun run() {
            if (prefs.getBoolean("roam", true) && !saver && !sleeping && !chatOpen && !dragging && menu.visibility != View.VISIBLE) roam()
            h.postDelayed(this, 15000L + Random.nextLong(25000))
        }
    }
    private fun roam() {
        val dm = resources.displayMetrics
        val tx = Random.nextInt(0, maxOf(1, dm.widthPixels - dp(165)))
        val ty = Random.nextInt(dp(60), maxOf(dp(61), dm.heightPixels - dp(270)))
        val sx = lp.x; val sy = lp.y
        val dist = Math.hypot((tx - sx).toDouble(), (ty - sy).toDouble())
        roamAnim?.cancel()
        roamAnim = ValueAnimator.ofFloat(0f, 1f).apply {
            duration = (dist / dp(60) * 1000).toLong().coerceIn(2500L, 9000L)
            interpolator = AccelerateDecelerateInterpolator()
            addUpdateListener { a ->
                val k = a.animatedValue as Float
                lp.x = (sx + (tx - sx) * k).toInt(); lp.y = (sy + (ty - sy) * k).toInt()
                try { wm.updateViewLayout(root, lp) } catch (e: Exception) {}
            }
            start()
        }
    }

    // ---------- Detección de apps (celos de TikTok, etc.) ----------
    private fun hasUsage(): Boolean {
        val a = getSystemService(AppOpsManager::class.java)
        return a.unsafeCheckOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), packageName) == AppOpsManager.MODE_ALLOWED
    }
    private fun cat(p: String) = when {
        p.contains("mikupet") -> "me"
        p.contains("musically") || p.contains("trill") || p.contains("tiktok") -> "tt"
        p.contains("whatsapp") || p.contains("instagram") || p.contains("telegram") || p.contains("messenger") || p.contains("snapchat") -> "chat"
        p.contains("minecraft") || p.contains("mojang") || p.contains("roblox") || p.contains("freefire") || p.contains("supercell") || p.contains("pubg") || p.contains("garena") -> "game"
        p.contains("youtube") || p.contains("netflix") -> "vid"
        else -> ""
    }
    private val appCheck = object : Runnable {
        override fun run() {
            try { if (hasUsage() && !sleeping && !chatOpen) checkApp() } catch (e: Exception) {}
            h.postDelayed(this, if (saver) 20000L else 5000L)
        }
    }
    private fun checkApp() {
        val um = getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
        val n = nowMs(); if (lastQ == 0L) lastQ = n - 5000
        val ev = um.queryEvents(lastQ, n); lastQ = n
        val e = UsageEvents.Event(); var p: String? = null
        while (ev.hasNextEvent()) { ev.getNextEvent(e); if (e.eventType == UsageEvents.Event.ACTIVITY_RESUMED) p = e.packageName }
        if (p == null || p == curApp) return
        curApp = p
        val c = cat(p)
        if (c == "me") { if (!jealous()) { setBase("flirt", 30000); say("¡Viniste a verme! 💙") }; return }
        when (c) {
            "tt", "chat" -> { jealousy = minOf(100, jealousy + 15); setBase(jel(), 120000); wiggle(); burst("💢", 2) }
            "game", "vid" -> { jealousy = minOf(100, jealousy + 4); if (!jealous()) setBase("flirt", 60000) }
        }
        appLines[c]?.let { say(it.random()) }
        save()
    }

    // ---------- Efectos ----------
    private fun tint() { if (sleeping) iv.setColorFilter(Color.argb(150, 0, 0, 40), PorterDuff.Mode.SRC_ATOP) else iv.clearColorFilter() }
    private fun bounce() { iv.animate().scaleX(1.08f).scaleY(1.08f).setDuration(110).withEndAction { iv.animate().scaleX(1f).scaleY(1f).setDuration(110).start() }.start() }
    private fun wiggle() { ObjectAnimator.ofFloat(iv, "rotation", 0f, -6f, 6f, -4f, 4f, 0f).setDuration(500).start() }
    private fun burst(e: String, n: Int) {
        repeat(n) { i ->
            val t = TextView(this).apply { text = e; textSize = 18f }
            stage.addView(t, FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL).apply {
                bottomMargin = dp(40 + Random.nextInt(60)); leftMargin = dp(Random.nextInt(-50, 50))
            })
            t.animate().translationY(-dp(60).toFloat()).alpha(0f).setStartDelay(i * 120L).setDuration(1300).withEndAction { stage.removeView(t) }.start()
        }
    }
    private fun showMenu() { menu.visibility = View.VISIBLE; roamAnim?.cancel(); h.removeCallbacks(hideMenu); h.postDelayed(hideMenu, 7000) }
    private val hideMenu = Runnable { menu.visibility = View.GONE }

    private fun say(t: String, ms: Long = 4800) {
        lastBubble = nowMs()
        bubble.text = t; bubble.visibility = View.VISIBLE
        h.removeCallbacks(hide); h.postDelayed(hide, ms)
        if (ttsOk && ms < 30000) tts?.speak(t.replace(Regex("[^\\p{L}\\p{N}\\s¿?¡!.,]"), ""), TextToSpeech.QUEUE_FLUSH, null, "m")
    }
    private val hide = Runnable { bubble.visibility = View.GONE }
    private fun save() { prefs.edit().putInt("a", affection).putInt("j", jealousy).putInt("m", milestone).apply() }

    override fun onInit(s: Int) {
        if (s == TextToSpeech.SUCCESS) { tts?.language = Locale("es", "MX"); tts?.setPitch(1.5f); ttsOk = true }
    }

    private fun startFg() {
        getSystemService(NotificationManager::class.java).createNotificationChannel(NotificationChannel("miku", "Miku", NotificationManager.IMPORTANCE_LOW))
        val stop = PendingIntent.getService(this, 0, Intent(this, OverlayService::class.java).setAction("STOP"), PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        val n = Notification.Builder(this, "miku").setContentTitle("Miku está contigo 💙")
            .setContentText("Mantén presionada a Miku para ver su menú")
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .addAction(Notification.Action.Builder(Icon.createWithResource(this, android.R.drawable.ic_menu_close_clear_cancel), "Dormir (cerrar)", stop).build())
            .build()
        if (Build.VERSION.SDK_INT >= 34) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE) else startForeground(1, n)
    }

    override fun onDestroy() {
        h.removeCallbacksAndMessages(null)
        roamAnim?.cancel()
        try { prefs.unregisterOnSharedPreferenceChangeListener(this) } catch (e: Exception) {}
        try { unregisterReceiver(rec) } catch (e: Exception) {}
        if (::root.isInitialized) wm.removeView(root)
        tts?.shutdown()
        super.onDestroy()
    }
}
