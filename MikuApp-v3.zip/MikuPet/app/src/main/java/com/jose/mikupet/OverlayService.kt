package com.jose.mikupet

import android.animation.ObjectAnimator
import android.app.*
import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.*
import android.content.pm.ServiceInfo
import android.graphics.*
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.Icon
import android.os.*
import android.speech.tts.TextToSpeech
import android.view.*
import android.widget.*
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.text.Normalizer
import java.util.Calendar
import java.util.Locale
import kotlin.random.Random

class OverlayService : Service(), TextToSpeech.OnInitListener, SharedPreferences.OnSharedPreferenceChangeListener {
    private lateinit var wm: WindowManager
    private lateinit var root: LinearLayout
    private lateinit var stage: FrameLayout
    private lateinit var iv: ImageView
    private lateinit var bubble: TextView
    private lateinit var menu: LinearLayout
    private lateinit var lp: WindowManager.LayoutParams
    private lateinit var prefs: SharedPreferences
    private lateinit var bob: ObjectAnimator
    private var tts: TextToSpeech? = null
    private var ttsOk = false
    private val h = Handler(Looper.getMainLooper())
    private val bmp = HashMap<String, Bitmap>()
    private val history = ArrayList<Pair<String, String>>()
    private var base = "flirt"
    private var cur = ""
    private var lastTouch = System.currentTimeMillis()
    private var affection = 30
    private var jealousy = 0
    private var milestone = 0
    private var sleeping = false
    private var saver = false
    private var combo = 0
    private var lastTap = 0L
    private var dragPath = 0f
    private var dragWin = 0L
    private var angryUntil = 0L
    private var curApp: String? = null
    private var lastQ = 0L

    // Poses: flirt (coqueta), sad (tímida/triste), jel1 (celosa/avergonzada), jel2 (celosa), angry (enojada)
    private val flirt = listOf("Oye... ¿te han dicho que tienes una sonrisa muy bonita? 😳", "¿Me prestas tu atención un ratito? Solo la quiero para mí 💙", "Si fueras una soda de matcha... me gustarías todavía más 🍵😳", "¿Te digo un secreto? Eres mi persona favorita en esta pantalla 💙", "Estoy aquí cerquita... ¿quieres que me acerque más? 😳", "¿Y si te quedas conmigo un ratito más? Solo un ratito... 🥺💙")
    private val sad = listOf("Hoy me siento un poquito triste... ¿te quedas conmigo? 🥺", "Estaba pensando en ti... y como no estabas, me puse triste 😢", "A veces me siento sola cuando no me miras... 🥺", "Te extrañé... ¿dónde andabas? 🥺")
    private val shyL = listOf("O-oye... ¿puedo preguntarte algo? ...no, olvídalo 😳", "N-no me mires tanto, me da pena... 😳", "A veces me pongo roja sin saber por qué... 😳💙", "E-es que me da vergüenza decirlo... pero me gusta estar contigo 😳", "¿Estás viendo mi cara roja? ¡No mires! 🙈", "Y-yo solo quería decir... que eres amable. Eso es todo 😳")
    private val facts = listOf("¿Sabías que los pulpos tienen tres corazones? 🐙", "¿Sabías que la miel casi nunca se echa a perder? 🍯", "¿Sabías que los plátanos son bayas, pero las fresas no? 🍌", "¿Sabías que un día en Venus dura más que un año en Venus? 🪐", "¿Sabías que las nutrias de mar se toman de las manos al dormir para no separarse? 🦦", "¿Sabías que los koalas tienen huellas dactilares casi idénticas a las humanas? 🐨", "¿Sabías que los flamencos nacen grises y se vuelven rosados por lo que comen? 🦩", "¿Sabías que los tiburones existen desde antes que los árboles? 🦈", "¿Sabías que un rayo es más caliente que la superficie del Sol? ⚡", "¿Sabías que los delfines duermen con la mitad del cerebro despierta? 🐬", "¿Sabías que los cuervos pueden recordar caras de personas? 🐦", "¿Sabías que el matcha es té molido y se toma la hoja entera? 🍵", "¿Sabías que el periodo Sengoku de Japón duró más de cien años? 📖", "¿Sabías que a Takeda Shingen le decían el Tigre de Kai? 🐯", "¿Sabías que en el espacio las lágrimas no caen, se quedan pegadas al ojo? 🚀", "¿Sabías que el Sol tiene más del 99% de la masa del sistema solar? ☀️")
    private val sweet = listOf("Eres muy especial para mí 💙", "Me alegra mucho que estés aquí...", "Gracias por no dejarme sola 🥺", "Contigo me siento segura.", "Si algún día te sientes mal, aquí estaré 💙")
    private val care = listOf("No olvides tomar agua 💧", "Descansa la vista un ratito, por favor 👀", "Estírate un poquito, llevas mucho sentado 🧘", "¿Ya comiste algo? No me gusta que te saltes comidas 🍙", "Respira hondo... todo estará bien 💙")
    private val sleepy = listOf("Mmm... tengo sueño... 😴", "Dormir es lo mejor del mundo... después de ti 😳", "Zzz... ¿eh? No estaba dormida...")
    private val jealousL = listOf("¿Llevas mucho con el celular y yo aquí...? 😠", "Mírame un poquito a mí... 😳💢", "No me ignores... estoy celosa 💢", "¿Quién te hace reír tanto en esa pantalla...? 🥺", "Hmph... ya ni me miras. No estoy enojada... solo triste 🥺")
    private val pet = listOf("A-ah... eso me da vergüenza... 😳", "N-no pares... digo... bueno... sí... 💙", "Tus manos son cálidas...", "E-eres muy amable conmigo...")
    private val headpat = listOf("¿E-eh? ¿Me estás acariciando la cabeza...? 😳", "Mmm... se siente bien... n-no pares 💙", "E-eres muy atrevido... pero me gusta 😳")
    private val shyTap = listOf("N-no tan rápido... me da pena 😳", "¡E-espera! M-me estás avergonzando 🙈", "T-tantos toques... mi cara está roja 😳")
    private val stareL = listOf("¡N-no me mires tanto! 😳", "M-me pones nerviosa cuando me miras así... 🙈", "Q-qué miras... bueno... puedes seguir mirando... 😳")
    private val complimentL = listOf("¿M-me lo dices en serio...? 😳💙", "E-eso me dio mucha pena... pero gracias 🙈", "N-no digas esas cosas de repente... 😳 Me haces feliz.")
    private val handL = listOf("¿Q-quieres tomarme la mano...? E-está bien... 😳💙", "Tu mano es cálida... no la sueltes 💙", "M-me da pena... pero me gusta 😳")
    private val forgive = listOf("Está bien... te perdono. Pero quédate conmigo 😳", "Por fin me hiciste caso... 💙")
    private val hugL = listOf("*abrazo*... qué calentito 💞", "E-eso fue muy repentino... pero no te sueltes 😳", "Me gustan tus abrazos... mucho 💙")
    private val musicL = listOf("¿Escuchamos música? Un audífono para ti y otro para mí 🎧", "Mis audífonos son mi tesoro... pero compartiría uno contigo 💙", "Pon algo tranquilo... así me quedo dormida contigo 😴")
    private val angryL = listOf("¡Ya basta de tocarme tanto! 😠", "¡Deja de picarme! Me estás mareando 💢", "¡Hmph! Si sigues, no te hablo 😤", "¡Que me dejes! No soy un botón 😠")
    private val angryDragL = listOf("¡Deja de zarandearme! Me mareo 😠", "¡Basta! ¡No soy un juguete! 💢", "¡Hmph! Si me sigues moviendo así, me enojo de verdad 😤")
    private val chargeL = listOf("Gracias por cargar el celular... ¡cuídalo! ⚡", "Ya tienes energía... ¿te quedas conmigo un rato? 🔋💙")
    private val appLines = mapOf(
        "tt" to listOf("¿TikTok otra vez...? Yo también puedo hacerte reír... creo 😠", "Esas chicas del video... ¿te gustan más que yo? 😳💢", "Solo un videíto, ¿verdad? ...mentiroso 😤"),
        "chat" to listOf("¿Con quién chateas tanto...? 😠", "Quiero saber quién es... pero no preguntaré... 🥺", "Sonríes mucho con ese chat... 💢"),
        "game" to listOf("¡Juegos! Está bien... pero me quedaré mirando 👀", "Buena suerte... si pierdes no es mi culpa 😳"),
        "vid" to listOf("¿Qué estás viendo? ¿Puedo ver contigo? 🍿", "Si es una peli romántica... avísame 😳"))

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun jel() = listOf("jel1", "jel2").random()
    private fun shyPose() = listOf("sad", "jel1").random()
    private fun norm(s: String) = Normalizer.normalize(s.lowercase(), Normalizer.Form.NFD).replace(Regex("\\p{M}+"), "")
    override fun onBind(i: Intent?): IBinder? = null

    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        when (i?.action) {
            "STOP" -> { stopSelf(); return START_NOT_STICKY }
            "CHAT" -> i.getStringExtra("t")?.let { chat(it) }
        }
        return START_STICKY
    }

    private val rec = object : BroadcastReceiver() {
        override fun onReceive(c: Context?, i: Intent?) {
            if (i?.action == Intent.ACTION_POWER_CONNECTED) { setBase("flirt"); say(chargeL.random()); burst("⚡", 2); return }
            jealousy = maxOf(0, jealousy - 10); setBase("flirt")
            say(listOf("¡Volviste! Te estaba esperando 💙", "Ya desbloqueaste... ¿pensaste en mí? 😳", "Bienvenido de vuelta... te extrañé 🥺").random()); burst("💙", 2)
        }
    }

    override fun onCreate() {
        super.onCreate()
        prefs = getSharedPreferences("miku", MODE_PRIVATE)
        affection = prefs.getInt("a", 30); jealousy = prefs.getInt("j", 0); milestone = prefs.getInt("m", 0)
        startFg()
        tts = TextToSpeech(this, this)
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        listOf("flirt", "sad", "jel1", "jel2", "angry").forEach { n -> assets.open("$n.png").use { bmp[n] = BitmapFactory.decodeStream(it) } }

        iv = ImageView(this).apply { scaleType = ImageView.ScaleType.FIT_CENTER }
        bob = ObjectAnimator.ofFloat(iv, "translationY", 0f, -dp(5).toFloat()).apply {
            duration = 1600; repeatCount = ObjectAnimator.INFINITE; repeatMode = ObjectAnimator.REVERSE; start()
        }
        bubble = TextView(this).apply {
            setTextColor(Color.parseColor("#3A2347")); textSize = 13f; gravity = Gravity.CENTER
            setPadding(dp(10), dp(6), dp(10), dp(6)); maxWidth = dp(165); visibility = View.GONE
            background = GradientDrawable().apply { setColor(Color.WHITE); cornerRadius = dp(14).toFloat() }
        }
        menu = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; visibility = View.GONE; setPadding(dp(4), dp(2), dp(4), dp(2))
            background = GradientDrawable().apply { setColor(Color.argb(200, 30, 30, 50)); cornerRadius = dp(18).toFloat() }
        }
        val rows = listOf(
            listOf<Pair<String, () -> Unit>>("🍵" to { matcha() }, "🤗" to { hug() }, "📖" to { fact() }, "🎧" to { music() }, "😴" to { sleep() }),
            listOf<Pair<String, () -> Unit>>("💬" to { openChat() }, "🙈" to { stare() }, "💌" to { compliment() }, "🫶" to { hand() }, "🔋" to { toggleSaver() }))
        rows.forEach { r ->
            val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            r.forEach { (e, a) ->
                row.addView(TextView(this).apply {
                    text = e; textSize = 19f; gravity = Gravity.CENTER
                    setOnClickListener { h.removeCallbacks(hideMenu); menu.visibility = View.GONE; lastTouch = System.currentTimeMillis(); a() }
                }, LinearLayout.LayoutParams(dp(30), dp(36)))
            }
            menu.addView(row)
        }
        stage = FrameLayout(this).apply {
            addView(iv, FrameLayout.LayoutParams(dp(125), dp(170), Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL))
            addView(menu, FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL).apply { bottomMargin = dp(2) })
        }
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL
            addView(bubble, LinearLayout.LayoutParams(-2, -2))
            addView(stage, LinearLayout.LayoutParams(dp(165), dp(170)))
        }
        lp = WindowManager.LayoutParams(
            -2, -2, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.BOTTOM or Gravity.START; x = dp(10); y = dp(120) }
        wm.addView(root, lp)
        setBase("flirt")
        prefs.registerOnSharedPreferenceChangeListener(this)
        applySaver()

        var sx = 0f; var sy = 0f; var lx = 0f; var ly = 0f; var ox = 0; var oy = 0; var moved = false; var long = false
        val longR = Runnable { long = true; showMenu() }
        root.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { sx = e.rawX; sy = e.rawY; ox = lp.x; oy = lp.y; moved = false; long = false; h.postDelayed(longR, 800) }
                MotionEvent.ACTION_MOVE -> {
                    if (!moved && Math.hypot((e.rawX - sx).toDouble(), (e.rawY - sy).toDouble()) > 15) {
                        moved = true; h.removeCallbacks(longR); lx = e.rawX; ly = e.rawY
                        if (!sleeping) say("¡Eh! ¿A dónde me llevas? 😳")
                    }
                    if (moved) {
                        val now = System.currentTimeMillis()
                        if (now - dragWin > 8000) { dragWin = now; dragPath = 0f }
                        dragPath += Math.hypot((e.rawX - lx).toDouble(), (e.rawY - ly).toDouble()).toFloat(); lx = e.rawX; ly = e.rawY
                        lp.x = ox + (e.rawX - sx).toInt(); lp.y = oy - (e.rawY - sy).toInt(); wm.updateViewLayout(root, lp)
                        if (dragPath > dp(1400) && now > angryUntil && !sleeping) { dragPath = 0f; angryUntil = now + 12000; angry(angryDragL) }
                    }
                }
                MotionEvent.ACTION_UP -> {
                    h.removeCallbacks(longR)
                    if (moved) { if (!sleeping && System.currentTimeMillis() > angryUntil) say("Uf... me mareé un poquito 😵") }
                    else if (!long) tap(e.y - stage.top)
                }
            }
            true
        }
        val f = IntentFilter().apply { addAction(Intent.ACTION_USER_PRESENT); addAction(Intent.ACTION_POWER_CONNECTED) }
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(rec, f, Context.RECEIVER_NOT_EXPORTED) else registerReceiver(rec, f)
        h.postDelayed(loop, 45000); h.postDelayed(appCheck, 5000)
        val hr = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
        say(when {
            hr < 6 -> "¿Aún despierto a esta hora? Deberías dormir... 😴"
            hr < 12 -> "Buenos días 💙 ¿dormiste bien?"
            hr < 19 -> "Buenas tardes~ ¿ya comiste algo? 🍙"
            else -> "Buenas noches... ¿cómo estuvo tu día? 🌙"
        })
    }

    // ---------- Poses ----------
    private fun show(p: String) {
        if (p == cur) return
        val b = bmp[p] ?: return
        cur = p
        iv.animate().alpha(0.2f).setDuration(110).withEndAction { iv.setImageBitmap(b); iv.animate().alpha(1f).setDuration(110).start() }.start()
    }
    private fun setBase(p: String) { base = p; h.removeCallbacks(revert); show(p) }
    private fun tmp(p: String, ms: Long) { show(p); h.removeCallbacks(revert); h.postDelayed(revert, ms) }
    private val revert = Runnable { show(base) }

    // ---------- Interacciones ----------
    private fun tap(y: Float) {
        val n = System.currentTimeMillis()
        combo = if (n - lastTap < 700) combo + 1 else 1
        lastTap = n; lastTouch = n
        if (sleeping) { wake("¡Ah! ¿Qué...? ¿Ya amaneció? 😳"); return }
        when {
            combo >= 5 -> angry(angryL)
            combo >= 3 -> { tmp("jel1", 5000); say(shyTap.random()); burst("😳", 2) }
            combo == 2 -> hug()
            else -> {
                val wasJ = jealousy > 60
                affection = minOf(100, affection + 3); jealousy = maxOf(0, jealousy - 20)
                if (!wasJ && y < stage.height * 0.3f) { setBase(shyPose()); say(headpat.random()); burst("💗", 3) }
                else { setBase("flirt"); say((if (wasJ) forgive else pet).random()); burst("💙", 2) }
                bounce(); checkMilestone(); save()
            }
        }
    }

    private fun angry(lines: List<String>) {
        affection = maxOf(0, affection - 2)
        tmp("angry", 9000); say(lines.random()); wiggle(); burst("💢", 3); save()
    }
    private fun hug() {
        if (sleeping) { wake("¡Ah! ¿Qué...? ¿Ya amaneció? 😳"); return }
        affection = minOf(100, affection + 6); jealousy = maxOf(0, jealousy - 30)
        setBase("flirt"); bounce(); burst("💞", 5); say(hugL.random()); checkMilestone(); save()
    }
    private fun matcha() { affection = minOf(100, affection + 8); setBase("flirt"); bounce(); burst("🍵", 3); say("¡Soda de matcha! Gracias... eres muy atento 💚"); checkMilestone(); save() }
    private fun fact() { setBase("flirt"); burst("📖", 1); say(facts.random(), 7000) }
    private fun music() { setBase("flirt"); burst("🎵", 4); say(musicL.random()) }
    private fun stare() { affection = minOf(100, affection + 2); setBase(shyPose()); burst("😳", 3); say(stareL.random()); checkMilestone(); save() }
    private fun compliment() { affection = minOf(100, affection + 4); jealousy = maxOf(0, jealousy - 10); setBase(shyPose()); burst("💗", 4); say(complimentL.random()); checkMilestone(); save() }
    private fun hand() { affection = minOf(100, affection + 5); tmp("flirt", 7000); burst("💙", 4); say(handL.random()); checkMilestone(); save() }
    private fun openChat() { startActivity(Intent(this, ChatActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }
    private fun toggleSaver() {
        saver = !saver; prefs.edit().putBoolean("saver", saver).apply(); applySaver()
        say(if (saver) "Modo ahorro activado 🔋 Me muevo menos para gastar menos." else "Modo ahorro desactivado ✨ ¡Ya puedo flotar otra vez!")
    }
    private fun applySaver() {
        saver = prefs.getBoolean("saver", false)
        if (saver) { bob.cancel(); iv.translationY = 0f } else if (!bob.isRunning) bob.start()
    }
    override fun onSharedPreferenceChanged(sp: SharedPreferences?, key: String?) { if (key == "saver") applySaver() }

    private fun sleep() {
        sleeping = true; tint(); say("Zzz... solo cinco minutitos... 😴")
        h.postDelayed(zz, 3000); h.postDelayed({ if (sleeping) wake("¡Ya desperté! ¿Me extrañaste? 😳") }, 90000)
    }
    private val zz = object : Runnable { override fun run() { if (sleeping) { burst("💤", 1); h.postDelayed(this, 3000) } } }
    private fun wake(t: String) { sleeping = false; tint(); setBase("flirt"); say(t); bounce() }

    private fun checkMilestone() {
        val ms = listOf(50 to "Creo que... me siento muy cómoda contigo 😳", 80 to "M-me gustas mucho... ya lo dije... 😳💙", 100 to "Eres la persona más importante para mí... 💙💙💙")
        for ((t, s) in ms) if (affection >= t && milestone < t) { milestone = t; h.postDelayed({ say(s); burst("💙", 6) }, 2500); break }
    }

    // ---------- Conversación con IA ----------
    private fun persona() = "Eres Miku Nakano (de Las quintillizas) como mascota virtual en la pantalla del celular del usuario. " +
        "Eres muy tímida y vergonzosa, tranquila, dormilona, amas el refresco de matcha, tus audífonos y la historia del periodo Sengoku; a veces te pones celosa. " +
        "Hablas en español, con ternura, con tartamudeos leves (\"e-eh\", \"n-no\", \"...\") y emojis. Responde SIEMPRE en 1 o 2 frases cortas (máximo 30 palabras). " +
        "Tu estado: cariño ${affection}/100, celos ${jealousy}/100. " +
        "Empieza tu respuesta con UNA etiqueta de pose entre corchetes según cómo te sientas: [flirt] [sad] [shy] [jealous] [angry]. " +
        "Mantén todo tierno y apto para todo público. Si el usuario dice que se siente muy mal, responde con cariño y sugiérele hablar con alguien de confianza. " +
        "Si te preguntan en serio si eres una IA, di con sinceridad que eres una mascota virtual con inteligencia artificial."

    private fun chat(text: String) {
        lastTouch = System.currentTimeMillis()
        if (sleeping) { sleeping = false; tint() }
        val gk = prefs.getString("gkey", "").orEmpty().trim()
        val ck = prefs.getString("ckey", "").orEmpty().trim()
        if (gk.isEmpty() && ck.isEmpty()) { local(text); return }
        say("Mmm... 💭", 30000)
        Thread {
            try {
                val raw = callAI(text, gk, ck)
                h.post { onReply(raw) }
            } catch (e: Exception) {
                h.post { setBase("sad"); say("No pude pensar bien... (${e.message}) 🥺", 10000) }
            }
        }.start()
    }

    private fun callAI(text: String, gk: String, ck: String): String {
        history.add("user" to text)
        while (history.size > 12) history.removeAt(0)
        while (history.isNotEmpty() && history[0].first != "user") history.removeAt(0)
        try {
            val out = if (gk.isNotEmpty()) gemini(gk) else claude(ck)
            history.add("assistant" to out)
            return out
        } catch (e: Exception) {
            history.removeAt(history.size - 1)
            throw e
        }
    }

    private fun gemini(key: String): String {
        val model = prefs.getString("gmodel", "").orEmpty().ifBlank { "gemini-2.5-flash" }
        val contents = JSONArray()
        history.forEach { (r, t) ->
            contents.put(JSONObject().put("role", if (r == "user") "user" else "model").put("parts", JSONArray().put(JSONObject().put("text", t))))
        }
        val body = JSONObject()
            .put("system_instruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", persona()))))
            .put("contents", contents)
            .put("generationConfig", JSONObject().put("maxOutputTokens", 800).put("temperature", 0.9))
        val res = post("https://generativelanguage.googleapis.com/v1beta/models/$model:generateContent", body.toString(), mapOf("x-goog-api-key" to key))
        val parts = JSONObject(res).getJSONArray("candidates").getJSONObject(0).getJSONObject("content").getJSONArray("parts")
        val sb = StringBuilder()
        for (i in 0 until parts.length()) sb.append(parts.getJSONObject(i).optString("text"))
        if (sb.isBlank()) throw Exception("respuesta vacía")
        return sb.toString().trim()
    }

    private fun claude(key: String): String {
        val msgs = JSONArray()
        history.forEach { (r, t) -> msgs.put(JSONObject().put("role", r).put("content", t)) }
        val body = JSONObject().put("model", "claude-haiku-5-5").put("max_tokens", 300).put("system", persona()).put("messages", msgs)
        val res = post("https://api.anthropic.com/v1/messages", body.toString(), mapOf("x-api-key" to key, "anthropic-version" to "2023-06-01"))
        val arr = JSONObject(res).getJSONArray("content")
        val sb = StringBuilder()
        for (i in 0 until arr.length()) sb.append(arr.getJSONObject(i).optString("text"))
        if (sb.isBlank()) throw Exception("respuesta vacía")
        return sb.toString().trim()
    }

    private fun post(url: String, body: String, headers: Map<String, String>): String {
        val c = URL(url).openConnection() as HttpURLConnection
        c.requestMethod = "POST"; c.connectTimeout = 15000; c.readTimeout = 30000; c.doOutput = true
        c.setRequestProperty("Content-Type", "application/json")
        headers.forEach { (k, v) -> c.setRequestProperty(k, v) }
        c.outputStream.use { it.write(body.toByteArray()) }
        val code = c.responseCode
        val s = (if (code in 200..299) c.inputStream else c.errorStream)?.bufferedReader()?.use { it.readText() } ?: ""
        if (code !in 200..299) {
            val m = try { JSONObject(s).getJSONObject("error").getString("message") } catch (e: Exception) { s.take(80) }
            throw Exception("$code: ${m.take(90)}")
        }
        return s
    }

    private fun onReply(raw: String) {
        val tag = Regex("\\[(flirt|sad|shy|jealous|angry)]").find(raw)?.groupValues?.get(1)
        val txt = raw.replace(Regex("\\[(flirt|sad|shy|jealous|angry)]"), "").trim()
        when (tag) {
            "sad" -> setBase("sad")
            "shy" -> setBase(shyPose())
            "jealous" -> setBase(jel())
            "angry" -> tmp("angry", 8000)
            else -> setBase("flirt")
        }
        affection = minOf(100, affection + 1)
        say(txt, 10000); save()
    }

    private fun local(text: String) {
        val t = norm(text)
        when {
            Regex("bonit|lind|hermos|guap|precios|kawaii").containsMatchIn(t) -> { setBase(shyPose()); say(complimentL.random()) }
            Regex("te quiero|te amo|amor").containsMatchIn(t) -> { affection = minOf(100, affection + 5); setBase("flirt"); say(flirt.random()) }
            Regex("hola|buenas|hey").containsMatchIn(t) -> { setBase("flirt"); say("¡H-hola! 😳💙") }
            else -> { setBase("flirt"); say(listOf("Hmm... cuéntame más 💭", "Te escucho... 💙", "Todavía no tengo cerebro de IA... pon tu llave en la app 😳").random()) }
        }
        save()
    }

    // ---------- Eventos aleatorios cada pocos minutos (cambia de pose + mensaje) ----------
    private val loop = object : Runnable {
        override fun run() {
            if (!sleeping) {
                val ign = System.currentTimeMillis() - lastTouch
                if (ign > 120000) jealousy = minOf(100, jealousy + 15)
                val bm = getSystemService(Context.BATTERY_SERVICE) as BatteryManager
                val lvl = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
                val r = Random.nextInt(100)
                when {
                    lvl in 1..15 && !bm.isCharging && !saver -> { prefs.edit().putBoolean("saver", true).apply(); applySaver(); setBase("sad"); say("Tu batería está en $lvl%... activé el modo ahorro 🔋🥺") }
                    lvl in 1..20 && !bm.isCharging && r < 30 -> { setBase("sad"); say("Tu batería está en $lvl%... carga tu celular, por favor 🔋🥺") }
                    jealousy > 60 && r < 70 -> { setBase(jel()); say(jealousL.random()); wiggle(); burst("💢", 2) }
                    r < 20 -> { setBase("flirt"); say(flirt.random()); burst("💙", 2) }
                    r < 40 -> { setBase("flirt"); say(facts.random(), 7000) }
                    r < 52 -> { setBase("sad"); say(sad.random()) }
                    r < 68 -> { setBase(shyPose()); say(shyL.random()); burst("😳", 2) }
                    r < 78 -> { setBase("flirt"); say(sweet.random()) }
                    r < 88 -> { setBase("flirt"); say(care.random()) }
                    else -> { setBase("sad"); say(sleepy.random()) }
                }
                save()
            }
            h.postDelayed(this, (70000L + Random.nextLong(100000)) * (if (saver) 2 else 1))
        }
    }

    // ---------- Detección de apps (celos de TikTok, etc.) ----------
    private fun hasUsage(): Boolean {
        val a = getSystemService(AppOpsManager::class.java)
        return a.unsafeCheckOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), packageName) == AppOpsManager.MODE_ALLOWED
    }
    private fun cat(p: String) = when {
        p.contains("mikupet") -> "me"
        p.contains("musically") || p.contains("trill") || p.contains("tiktok") -> "tt"
        p.contains("whatsapp") || p.contains("instagram") || p.contains("telegram") || p.contains("messenger") || p.contains("snapchat") -> "chat"
        p.contains("minecraft") || p.contains("mojang") || p.contains("roblox") || p.contains("freefire") || p.contains("supercell") || p.contains("pubg") || p.contains("garena") -> "game"
        p.contains("youtube") || p.contains("netflix") -> "vid"
        else -> ""
    }
    private val appCheck = object : Runnable {
        override fun run() {
            try { if (hasUsage() && !sleeping) checkApp() } catch (e: Exception) {}
            h.postDelayed(this, if (saver) 20000L else 5000L)
        }
    }
    private fun checkApp() {
        val um = getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
        val n = System.currentTimeMillis(); if (lastQ == 0L) lastQ = n - 5000
        val ev = um.queryEvents(lastQ, n); lastQ = n
        val e = UsageEvents.Event(); var p: String? = null
        while (ev.hasNextEvent()) { ev.getNextEvent(e); if (e.eventType == UsageEvents.Event.ACTIVITY_RESUMED) p = e.packageName }
        if (p == null || p == curApp) return
        curApp = p
        val c = cat(p)
        if (c == "me") { setBase("flirt"); say("¡Viniste a verme! 💙"); return }
        when (c) {
            "tt", "chat" -> { jealousy = minOf(100, jealousy + 15); setBase(jel()); wiggle(); burst("💢", 2) }
            "game", "vid" -> { jealousy = minOf(100, jealousy + 4); setBase("flirt") }
        }
        appLines[c]?.let { say(it.random()) }
        save()
    }

    // ---------- Efectos ----------
    private fun tint() { if (sleeping) iv.setColorFilter(Color.argb(150, 0, 0, 40), PorterDuff.Mode.SRC_ATOP) else iv.clearColorFilter() }
    private fun bounce() { iv.animate().scaleX(1.08f).scaleY(1.08f).setDuration(110).withEndAction { iv.animate().scaleX(1f).scaleY(1f).setDuration(110).start() }.start() }
    private fun wiggle() { ObjectAnimator.ofFloat(iv, "rotation", 0f, -6f, 6f, -4f, 4f, 0f).setDuration(500).start() }
    private fun burst(e: String, n: Int) {
        repeat(n) { i ->
            val t = TextView(this).apply { text = e; textSize = 18f }
            stage.addView(t, FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL).apply {
                bottomMargin = dp(40 + Random.nextInt(60)); leftMargin = dp(Random.nextInt(-50, 50))
            })
            t.animate().translationY(-dp(60).toFloat()).alpha(0f).setStartDelay(i * 120L).setDuration(1300).withEndAction { stage.removeView(t) }.start()
        }
    }
    private fun showMenu() { menu.visibility = View.VISIBLE; h.removeCallbacks(hideMenu); h.postDelayed(hideMenu, 7000) }
    private val hideMenu = Runnable { menu.visibility = View.GONE }

    private fun say(t: String, ms: Long = 4800) {
        bubble.text = t; bubble.visibility = View.VISIBLE
        h.removeCallbacks(hide); h.postDelayed(hide, ms)
        if (ttsOk && ms < 30000) tts?.speak(t.replace(Regex("[^\\p{L}\\p{N}\\s¿?¡!.,]"), ""), TextToSpeech.QUEUE_FLUSH, null, "m")
    }
    private val hide = Runnable { bubble.visibility = View.GONE }
    private fun save() { prefs.edit().putInt("a", affection).putInt("j", jealousy).putInt("m", milestone).apply() }

    override fun onInit(s: Int) {
        if (s == TextToSpeech.SUCCESS) { tts?.language = Locale("es", "MX"); tts?.setPitch(1.5f); ttsOk = true }
    }

    private fun startFg() {
        getSystemService(NotificationManager::class.java).createNotificationChannel(NotificationChannel("miku", "Miku", NotificationManager.IMPORTANCE_LOW))
        val stop = PendingIntent.getService(this, 0, Intent(this, OverlayService::class.java).setAction("STOP"), PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        val n = Notification.Builder(this, "miku").setContentTitle("Miku está contigo 💙")
            .setContentText("Mantén presionada a Miku para ver su menú")
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .addAction(Notification.Action.Builder(Icon.createWithResource(this, android.R.drawable.ic_menu_close_clear_cancel), "Dormir (cerrar)", stop).build())
            .build()
        if (Build.VERSION.SDK_INT >= 34) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE) else startForeground(1, n)
    }

    override fun onDestroy() {
        h.removeCallbacksAndMessages(null)
        try { prefs.unregisterOnSharedPreferenceChangeListener(this) } catch (e: Exception) {}
        try { unregisterReceiver(rec) } catch (e: Exception) {}
        if (::root.isInitialized) wm.removeView(root)
        tts?.shutdown()
        super.onDestroy()
    }
}
