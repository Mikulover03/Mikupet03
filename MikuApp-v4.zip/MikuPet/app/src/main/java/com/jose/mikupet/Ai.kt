package com.jose.mikupet

import android.content.SharedPreferences
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL

object Ai {
    fun ask(prefs: SharedPreferences, history: List<Pair<String, String>>, sys: String): String {
        val gk = prefs.getString("gkey", "").orEmpty().trim()
        val ck = prefs.getString("ckey", "").orEmpty().trim()
        return when {
            gk.isNotEmpty() -> gemini(gk, prefs.getString("gmodel", "").orEmpty().trim(), history, sys)
            ck.isNotEmpty() -> claude(ck, history, sys)
            else -> throw Exception("falta la llave")
        }
    }

    private fun gemini(key: String, model: String, history: List<Pair<String, String>>, sys: String): String {
        val contents = JSONArray()
        history.forEach { (r, t) ->
            contents.put(JSONObject().put("role", if (r == "user") "user" else "model").put("parts", JSONArray().put(JSONObject().put("text", t))))
        }
        val body = JSONObject()
            .put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", sys))))
            .put("contents", contents)
            .put("generationConfig", JSONObject().put("maxOutputTokens", 1024).put("temperature", 0.9))
            .toString()
        var last: Exception? = null
        for (m in listOf(model.ifBlank { "gemini-2.5-flash" }, "gemini-flash-latest", "gemini-2.5-flash").distinct()) {
            try {
                val res = post("https://generativelanguage.googleapis.com/v1beta/models/$m:generateContent", body, mapOf("x-goog-api-key" to key))
                val cands = JSONObject(res).optJSONArray("candidates") ?: throw Exception("respuesta bloqueada")
                val parts = cands.getJSONObject(0).optJSONObject("content")?.optJSONArray("parts") ?: throw Exception("respuesta vacía")
                val sb = StringBuilder()
                for (i in 0 until parts.length()) sb.append(parts.getJSONObject(i).optString("text"))
                if (sb.isBlank()) throw Exception("respuesta vacía")
                return sb.toString().trim()
            } catch (e: Exception) {
                last = e
                if (e.message?.startsWith("404") != true) throw e
            }
        }
        throw last ?: Exception("sin respuesta")
    }

    private fun claude(key: String, history: List<Pair<String, String>>, sys: String): String {
        val msgs = JSONArray()
        history.forEach { (r, t) -> msgs.put(JSONObject().put("role", r).put("content", t)) }
        val body = JSONObject().put("model", "claude-haiku-5-5").put("max_tokens", 300).put("system", sys).put("messages", msgs).toString()
        val res = post("https://api.anthropic.com/v1/messages", body, mapOf("x-api-key" to key, "anthropic-version" to "2023-06-01"))
        val arr = JSONObject(res).getJSONArray("content")
        val sb = StringBuilder()
        for (i in 0 until arr.length()) sb.append(arr.getJSONObject(i).optString("text"))
        if (sb.isBlank()) throw Exception("respuesta vacía")
        return sb.toString().trim()
    }

    private fun post(url: String, body: String, headers: Map<String, String>): String {
        val c = URL(url).openConnection() as HttpURLConnection
        c.requestMethod = "POST"; c.connectTimeout = 15000; c.readTimeout = 30000; c.doOutput = true
        c.setRequestProperty("Content-Type", "application/json")
        headers.forEach { (k, v) -> c.setRequestProperty(k, v) }
        c.outputStream.use { it.write(body.toByteArray()) }
        val code = c.responseCode
        val s = (if (code in 200..299) c.inputStream else c.errorStream)?.bufferedReader()?.use { it.readText() } ?: ""
        if (code !in 200..299) {
            val m = try { JSONObject(s).getJSONObject("error").getString("message") } catch (e: Exception) { s.take(80) }
            throw Exception("$code: ${m.take(90)}")
        }
        return s
    }
}
