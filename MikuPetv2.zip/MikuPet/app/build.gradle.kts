plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }
android {
    namespace = "com.jose.mikupet"
    compileSdk = 34
    defaultConfig { applicationId = "com.jose.mikupet"; minSdk = 29; targetSdk = 34; versionCode = 1; versionName = "1.0" }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
    signingConfigs { getByName("debug") { storeFile = file("../mikupet.keystore"); storePassword = "android"; keyAlias = "androiddebugkey"; keyPassword = "android" } }
    kotlinOptions { jvmTarget = "17" }
}
