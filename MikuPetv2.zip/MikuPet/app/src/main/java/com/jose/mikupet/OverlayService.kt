package com.jose.mikupet

import android.animation.ObjectAnimator
import android.app.*
import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.*
import android.content.pm.ServiceInfo
import android.graphics.*
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.Icon
import android.os.*
import android.speech.tts.TextToSpeech
import android.view.*
import android.widget.*
import java.util.Calendar
import java.util.Locale
import kotlin.random.Random

class OverlayService : Service(), TextToSpeech.OnInitListener {
    private lateinit var wm: WindowManager
    private lateinit var root: LinearLayout
    private lateinit var stage: FrameLayout
    private lateinit var iv: ImageView
    private lateinit var bubble: TextView
    private lateinit var menu: LinearLayout
    private lateinit var lp: WindowManager.LayoutParams
    private lateinit var prefs: SharedPreferences
    private var tts: TextToSpeech? = null
    private var ttsOk = false
    private val h = Handler(Looper.getMainLooper())
    private val bmp = HashMap<String, Bitmap>()
    private var base = "flirt"
    private var cur = ""
    private var lastTouch = System.currentTimeMillis()
    private var affection = 30
    private var jealousy = 0
    private var milestone = 0
    private var sleeping = false
    private var combo = 0
    private var lastTap = 0L
    private var curApp: String? = null
    private var lastQ = 0L

    // Poses: flirt (coqueta), sad (triste), jel1/jel2 (celosa/enojada), angry (enojada al tocarla mucho)
    private val flirt = listOf("Oye... ¿te han dicho que tienes una sonrisa muy bonita? 😳", "¿Me prestas tu atención un ratito? Solo la quiero para mí 💙", "Si fueras una soda de matcha... me gustarías todavía más 🍵😳", "Me gusta cuando me miras así... n-no digo cómo 😳", "¿Te digo un secreto? Eres mi persona favorita en esta pantalla 💙", "Estoy aquí cerquita... ¿quieres que me acerque más? 😳", "Hoy te ves muy bien... aunque no te vea, lo sé 😊💙", "¿Y si te quedas conmigo un ratito más? Solo un ratito... 🥺💙")
    private val sad = listOf("Hoy me siento un poquito triste... ¿te quedas conmigo? 🥺", "Estaba pensando en ti... y como no estabas, me puse triste 😢", "A veces me siento sola cuando no me miras... 🥺", "No te preocupes, ya se me pasa... pero un abrazo ayudaría 😢", "Te extrañé... ¿dónde andabas? 🥺", "Cuando no estás, todo se siente muy silencioso...")
    private val facts = listOf("¿Sabías que los pulpos tienen tres corazones? 🐙", "¿Sabías que la miel casi nunca se echa a perder? 🍯", "¿Sabías que los plátanos son bayas, pero las fresas no? 🍌", "¿Sabías que un día en Venus dura más que un año en Venus? 🪐", "¿Sabías que las nutrias de mar se toman de las manos al dormir para no separarse? 🦦", "¿Sabías que los koalas tienen huellas dactilares casi idénticas a las humanas? 🐨", "¿Sabías que los flamencos nacen grises y se vuelven rosados por lo que comen? 🦩", "¿Sabías que los tiburones existen desde antes que los árboles? 🦈", "¿Sabías que la Torre Eiffel crece hasta unos 15 cm en verano por el calor? 🗼", "¿Sabías que un rayo es más caliente que la superficie del Sol? ⚡", "¿Sabías que los delfines duermen con la mitad del cerebro despierta? 🐬", "¿Sabías que los cocodrilos no pueden sacar la lengua? 🐊", "¿Sabías que los cuervos pueden recordar caras de personas? 🐦", "¿Sabías que el matcha es té molido y se toma la hoja entera? 🍵", "¿Sabías que el periodo Sengoku de Japón duró más de cien años? 📖", "¿Sabías que a Takeda Shingen le decían el Tigre de Kai? 🐯", "¿Sabías que los generales del Sengoku daban órdenes con abanicos de guerra? 📖", "¿Sabías que en el espacio las lágrimas no caen, se quedan pegadas al ojo? 🚀", "¿Sabías que tu cuerpo tiene unos 37 billones de células? 🧬", "¿Sabías que el Sol tiene más del 99% de la masa del sistema solar? ☀️")
    private val sweet = listOf("Eres muy especial para mí 💙", "Me alegra mucho que estés aquí...", "Gracias por no dejarme sola 🥺", "Contigo me siento segura.", "Creo que eres lo mejor de mi día... n-no lo repetiré 😳", "Si algún día te sientes mal, aquí estaré 💙")
    private val care = listOf("No olvides tomar agua 💧", "Descansa la vista un ratito, por favor 👀", "Estírate un poquito, llevas mucho sentado 🧘", "¿Ya comiste algo? No me gusta que te saltes comidas 🍙", "Respira hondo... todo estará bien 💙")
    private val sleepy = listOf("Mmm... tengo sueño... 😴", "¿Y si tomamos una siesta? ...digo, cada uno en lo suyo 😳", "Dormir es lo mejor del mundo... después de ti 😳", "Zzz... ¿eh? No estaba dormida...")
    private val jealousL = listOf("¿Llevas mucho con el celular y yo aquí...? 😠", "Mírame un poquito a mí... 😳💢", "No me ignores... estoy celosa 💢", "¿Quién te hace reír tanto en esa pantalla...? 🥺", "Hmph... ya ni me miras. No estoy enojada... solo triste 🥺")
    private val pet = listOf("A-ah... eso me da vergüenza... 😳", "N-no pares... digo... bueno... sí... 💙", "Tus manos son cálidas...", "E-eres muy amable conmigo...")
    private val forgive = listOf("Está bien... te perdono. Pero quédate conmigo 😳", "Por fin me hiciste caso... 💙")
    private val hugL = listOf("*abrazo*... qué calentito 💞", "E-eso fue muy repentino... pero no te sueltes 😳", "Me gustan tus abrazos... mucho 💙")
    private val musicL = listOf("¿Escuchamos música? Un audífono para ti y otro para mí 🎧", "Mis audífonos son mi tesoro... pero compartiría uno contigo 💙", "Pon algo tranquilo... así me quedo dormida contigo 😴")
    private val angryL = listOf("¡Ya basta de tocarme tanto! 😠", "¡Deja de picarme! Me estás mareando 💢", "¡Hmph! Si sigues, no te hablo 😤", "¡Que me dejes! No soy un botón 😠")
    private val appLines = mapOf(
        "tt" to listOf("¿TikTok otra vez...? Yo también puedo hacerte reír... creo 😠", "Esas chicas del video... ¿te gustan más que yo? 😳💢", "Solo un videíto, ¿verdad? ...mentiroso 😤"),
        "chat" to listOf("¿Con quién chateas tanto...? 😠", "Quiero saber quién es... pero no preguntaré... 🥺", "Sonríes mucho con ese chat... 💢"),
        "game" to listOf("¡Juegos! Está bien... pero me quedaré mirando 👀", "Buena suerte... si pierdes no es mi culpa 😳"),
        "vid" to listOf("¿Qué estás viendo? ¿Puedo ver contigo? 🍿", "Si es una peli romántica... avísame 😳"))

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun jel() = listOf("jel1", "jel2").random()
    override fun onBind(i: Intent?): IBinder? = null
    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        if (i?.action == "STOP") { stopSelf(); return START_NOT_STICKY }
        return START_STICKY
    }

    private val userPresent = object : BroadcastReceiver() {
        override fun onReceive(c: Context?, i: Intent?) {
            jealousy = maxOf(0, jealousy - 10); setBase("flirt")
            say(listOf("¡Volviste! Te estaba esperando 💙", "Ya desbloqueaste... ¿pensaste en mí? 😳", "Bienvenido de vuelta... te extrañé 🥺").random()); burst("💙", 2)
        }
    }

    override fun onCreate() {
        super.onCreate()
        prefs = getSharedPreferences("miku", MODE_PRIVATE)
        affection = prefs.getInt("a", 30); jealousy = prefs.getInt("j", 0); milestone = prefs.getInt("m", 0)
        startFg()
        tts = TextToSpeech(this, this)
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        listOf("flirt", "sad", "jel1", "jel2", "angry").forEach { n -> assets.open("$n.png").use { bmp[n] = BitmapFactory.decodeStream(it) } }

        iv = ImageView(this).apply { scaleType = ImageView.ScaleType.FIT_CENTER }
        ObjectAnimator.ofFloat(iv, "translationY", 0f, -dp(5).toFloat()).apply {
            duration = 1600; repeatCount = ObjectAnimator.INFINITE; repeatMode = ObjectAnimator.REVERSE; start()
        }
        bubble = TextView(this).apply {
            setTextColor(Color.parseColor("#3A2347")); textSize = 13f; gravity = Gravity.CENTER
            setPadding(dp(10), dp(6), dp(10), dp(6)); maxWidth = dp(165); visibility = View.GONE
            background = GradientDrawable().apply { setColor(Color.WHITE); cornerRadius = dp(14).toFloat() }
        }
        menu = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER; visibility = View.GONE
            background = GradientDrawable().apply { setColor(Color.argb(190, 30, 30, 50)); cornerRadius = dp(18).toFloat() }
        }
        val acts = listOf<Pair<String, () -> Unit>>("🍵" to { matcha() }, "🤗" to { hug() }, "📖" to { fact() }, "🎧" to { music() }, "😴" to { sleep() })
        acts.forEach { (e, a) ->
            menu.addView(TextView(this).apply {
                text = e; textSize = 20f; gravity = Gravity.CENTER
                setOnClickListener { h.removeCallbacks(hideMenu); menu.visibility = View.GONE; lastTouch = System.currentTimeMillis(); a() }
            }, LinearLayout.LayoutParams(dp(32), dp(38)))
        }
        stage = FrameLayout(this).apply {
            addView(iv, FrameLayout.LayoutParams(dp(125), dp(170), Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL))
            addView(menu, FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL).apply { bottomMargin = dp(2) })
        }
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER_HORIZONTAL
            addView(bubble, LinearLayout.LayoutParams(-2, -2))
            addView(stage, LinearLayout.LayoutParams(dp(165), dp(170)))
        }
        lp = WindowManager.LayoutParams(
            -2, -2, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.BOTTOM or Gravity.START; x = dp(10); y = dp(120) }
        wm.addView(root, lp)
        setBase("flirt")

        var sx = 0f; var sy = 0f; var ox = 0; var oy = 0; var moved = false; var long = false
        val longR = Runnable { long = true; showMenu() }
        root.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { sx = e.rawX; sy = e.rawY; ox = lp.x; oy = lp.y; moved = false; long = false; h.postDelayed(longR, 800) }
                MotionEvent.ACTION_MOVE -> {
                    if (!moved && Math.hypot((e.rawX - sx).toDouble(), (e.rawY - sy).toDouble()) > 15) {
                        moved = true; h.removeCallbacks(longR)
                        if (!sleeping) say("¡Eh! ¿A dónde me llevas? 😳")
                    }
                    if (moved) { lp.x = ox + (e.rawX - sx).toInt(); lp.y = oy - (e.rawY - sy).toInt(); wm.updateViewLayout(root, lp) }
                }
                MotionEvent.ACTION_UP -> {
                    h.removeCallbacks(longR)
                    if (moved) { if (!sleeping) say("Uf... me mareé un poquito 😵") } else if (!long) tap()
                }
            }
            true
        }
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(userPresent, IntentFilter(Intent.ACTION_USER_PRESENT), Context.RECEIVER_NOT_EXPORTED)
        else registerReceiver(userPresent, IntentFilter(Intent.ACTION_USER_PRESENT))
        tint()
        h.postDelayed(loop, 45000); h.postDelayed(appCheck, 5000)
        val hr = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
        say(when {
            hr < 6 -> "¿Aún despierto a esta hora? Deberías dormir... 😴"
            hr < 12 -> "Buenos días 💙 ¿dormiste bien?"
            hr < 19 -> "Buenas tardes~ ¿ya comiste algo? 🍙"
            else -> "Buenas noches... ¿cómo estuvo tu día? 🌙"
        })
    }

    // ---------- Poses ----------
    private fun show(p: String) {
        if (p == cur) return
        val b = bmp[p] ?: return
        cur = p
        iv.animate().alpha(0.2f).setDuration(110).withEndAction { iv.setImageBitmap(b); iv.animate().alpha(1f).setDuration(110).start() }.start()
    }
    private fun setBase(p: String) { base = p; h.removeCallbacks(revert); show(p) }
    private fun tmp(p: String, ms: Long) { show(p); h.removeCallbacks(revert); h.postDelayed(revert, ms) }
    private val revert = Runnable { show(base) }

    // ---------- Interacciones ----------
    private fun tap() {
        val n = System.currentTimeMillis()
        combo = if (n - lastTap < 700) combo + 1 else 1
        lastTap = n; lastTouch = n
        if (sleeping) { wake("¡Ah! ¿Qué...? ¿Ya amaneció? 😳"); return }
        if (combo >= 5) {
            affection = maxOf(0, affection - 2)
            tmp("angry", 9000); say(angryL.random()); wiggle(); burst("💢", 3); save(); return
        }
        if (combo == 2) { hug(); return }
        val wasJ = jealousy > 60
        affection = minOf(100, affection + 3); jealousy = maxOf(0, jealousy - 20)
        setBase("flirt"); bounce(); burst("💙", 2)
        say((if (wasJ) forgive else pet).random())
        checkMilestone(); save()
    }

    private fun hug() {
        if (sleeping) { wake("¡Ah! ¿Qué...? ¿Ya amaneció? 😳"); return }
        affection = minOf(100, affection + 6); jealousy = maxOf(0, jealousy - 30)
        setBase("flirt"); bounce(); burst("💞", 5); say(hugL.random()); checkMilestone(); save()
    }
    private fun matcha() { affection = minOf(100, affection + 8); setBase("flirt"); bounce(); burst("🍵", 3); say("¡Soda de matcha! Gracias... eres muy atento 💚"); checkMilestone(); save() }
    private fun fact() { setBase("flirt"); burst("📖", 1); say(facts.random(), 7000) }
    private fun music() { setBase("flirt"); burst("🎵", 4); say(musicL.random()) }

    private fun sleep() {
        sleeping = true; tint(); say("Zzz... solo cinco minutitos... 😴")
        h.postDelayed(zz, 3000); h.postDelayed({ if (sleeping) wake("¡Ya desperté! ¿Me extrañaste? 😳") }, 90000)
    }
    private val zz = object : Runnable { override fun run() { if (sleeping) { burst("💤", 1); h.postDelayed(this, 3000) } } }
    private fun wake(t: String) { sleeping = false; tint(); setBase("flirt"); say(t); bounce() }

    private fun checkMilestone() {
        val ms = listOf(50 to "Creo que... me siento muy cómoda contigo 😳", 80 to "M-me gustas mucho... ya lo dije... 😳💙", 100 to "Eres la persona más importante para mí... 💙💙💙")
        for ((t, s) in ms) if (affection >= t && milestone < t) { milestone = t; h.postDelayed({ say(s); burst("💙", 6) }, 2500); break }
    }

    // ---------- Eventos aleatorios cada pocos minutos (cambia de pose + mensaje) ----------
    private val loop = object : Runnable {
        override fun run() {
            if (!sleeping) {
                val ign = System.currentTimeMillis() - lastTouch
                if (ign > 120000) jealousy = minOf(100, jealousy + 15)
                val bm = getSystemService(Context.BATTERY_SERVICE) as BatteryManager
                val lvl = bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
                val r = Random.nextInt(100)
                when {
                    lvl in 1..20 && !bm.isCharging && r < 35 -> { setBase("sad"); say("Tu batería está en $lvl%... carga tu celular, por favor 🔋🥺") }
                    jealousy > 60 && r < 70 -> { setBase(jel()); say(jealousL.random()); wiggle(); burst("💢", 2) }
                    r < 25 -> { setBase("flirt"); say(flirt.random()); burst("💙", 2) }
                    r < 50 -> { setBase("flirt"); say(facts.random(), 7000) }
                    r < 66 -> { setBase("sad"); say(sad.random()) }
                    r < 76 -> { setBase("flirt"); say(sweet.random()) }
                    r < 86 -> { setBase("flirt"); say(care.random()) }
                    else -> { setBase("sad"); say(sleepy.random()) }
                }
                save()
            }
            h.postDelayed(this, 70000L + Random.nextLong(100000))
        }
    }

    // ---------- Detección de apps (celos de TikTok, etc.) ----------
    private fun hasUsage(): Boolean {
        val a = getSystemService(AppOpsManager::class.java)
        return a.unsafeCheckOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, Process.myUid(), packageName) == AppOpsManager.MODE_ALLOWED
    }
    private fun cat(p: String) = when {
        p.contains("mikupet") -> "me"
        p.contains("musically") || p.contains("trill") || p.contains("tiktok") -> "tt"
        p.contains("whatsapp") || p.contains("instagram") || p.contains("telegram") || p.contains("messenger") || p.contains("snapchat") -> "chat"
        p.contains("minecraft") || p.contains("mojang") || p.contains("roblox") || p.contains("freefire") || p.contains("supercell") || p.contains("pubg") || p.contains("garena") -> "game"
        p.contains("youtube") || p.contains("netflix") -> "vid"
        else -> ""
    }
    private val appCheck = object : Runnable {
        override fun run() {
            try { if (hasUsage() && !sleeping) checkApp() } catch (e: Exception) {}
            h.postDelayed(this, 5000)
        }
    }
    private fun checkApp() {
        val um = getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
        val n = System.currentTimeMillis(); if (lastQ == 0L) lastQ = n - 5000
        val ev = um.queryEvents(lastQ, n); lastQ = n
        val e = UsageEvents.Event(); var p: String? = null
        while (ev.hasNextEvent()) { ev.getNextEvent(e); if (e.eventType == UsageEvents.Event.ACTIVITY_RESUMED) p = e.packageName }
        if (p == null || p == curApp) return
        curApp = p
        val c = cat(p)
        if (c == "me") { setBase("flirt"); say("¡Viniste a verme! 💙"); return }
        when (c) {
            "tt", "chat" -> { jealousy = minOf(100, jealousy + 15); setBase(jel()); wiggle(); burst("💢", 2) }
            "game", "vid" -> { jealousy = minOf(100, jealousy + 4); setBase("flirt") }
        }
        appLines[c]?.let { say(it.random()) }
        save()
    }

    // ---------- Efectos ----------
    private fun tint() { if (sleeping) iv.setColorFilter(Color.argb(150, 0, 0, 40), PorterDuff.Mode.SRC_ATOP) else iv.clearColorFilter() }
    private fun bounce() { iv.animate().scaleX(1.08f).scaleY(1.08f).setDuration(110).withEndAction { iv.animate().scaleX(1f).scaleY(1f).setDuration(110).start() }.start() }
    private fun wiggle() { ObjectAnimator.ofFloat(iv, "rotation", 0f, -6f, 6f, -4f, 4f, 0f).setDuration(500).start() }
    private fun burst(e: String, n: Int) {
        repeat(n) { i ->
            val t = TextView(this).apply { text = e; textSize = 18f }
            stage.addView(t, FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL).apply {
                bottomMargin = dp(40 + Random.nextInt(60)); leftMargin = dp(Random.nextInt(-50, 50))
            })
            t.animate().translationY(-dp(60).toFloat()).alpha(0f).setStartDelay(i * 120L).setDuration(1300).withEndAction { stage.removeView(t) }.start()
        }
    }
    private fun showMenu() { menu.visibility = View.VISIBLE; h.removeCallbacks(hideMenu); h.postDelayed(hideMenu, 6000) }
    private val hideMenu = Runnable { menu.visibility = View.GONE }

    private fun say(t: String, ms: Long = 4800) {
        bubble.text = t; bubble.visibility = View.VISIBLE
        h.removeCallbacks(hide); h.postDelayed(hide, ms)
        if (ttsOk) tts?.speak(t.replace(Regex("[^\\p{L}\\p{N}\\s¿?¡!.,]"), ""), TextToSpeech.QUEUE_FLUSH, null, "m")
    }
    private val hide = Runnable { bubble.visibility = View.GONE }
    private fun save() { prefs.edit().putInt("a", affection).putInt("j", jealousy).putInt("m", milestone).apply() }

    override fun onInit(s: Int) {
        if (s == TextToSpeech.SUCCESS) { tts?.language = Locale("es", "MX"); tts?.setPitch(1.5f); ttsOk = true }
    }

    private fun startFg() {
        getSystemService(NotificationManager::class.java).createNotificationChannel(NotificationChannel("miku", "Miku", NotificationManager.IMPORTANCE_LOW))
        val stop = PendingIntent.getService(this, 0, Intent(this, OverlayService::class.java).setAction("STOP"), PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        val n = Notification.Builder(this, "miku").setContentTitle("Miku está contigo 💙")
            .setContentText("Mantén presionada a Miku para ver su menú")
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .addAction(Notification.Action.Builder(Icon.createWithResource(this, android.R.drawable.ic_menu_close_clear_cancel), "Dormir (cerrar)", stop).build())
            .build()
        if (Build.VERSION.SDK_INT >= 34) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE) else startForeground(1, n)
    }

    override fun onDestroy() {
        h.removeCallbacksAndMessages(null)
        try { unregisterReceiver(userPresent) } catch (e: Exception) {}
        if (::root.isInitialized) wm.removeView(root)
        tts?.shutdown()
        super.onDestroy()
    }
}
